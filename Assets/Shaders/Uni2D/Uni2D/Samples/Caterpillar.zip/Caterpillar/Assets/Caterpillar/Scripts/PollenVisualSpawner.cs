﻿using UnityEngine;
using System.Collections;

public class PollenVisualSpawner : MonoBehaviour
{
	private PollenVisual m_rPollenVisual;
	
	public PollenVisual PollenVisual
	{
		get
		{
			return m_rPollenVisual;
		}
	}
	
	private void Awake()
	{
		m_rPollenVisual = Instantiate(ItemFactory.Instance.pollenVisualPrefab) as PollenVisual;
		m_rPollenVisual.transform.parent = transform;
		m_rPollenVisual.transform.localPosition = Vector2.zero;
		m_rPollenVisual.transform.localScale = Vector3.one;
		m_rPollenVisual.transform.localRotation = Quaternion.identity;
		SetLayerRecursively(m_rPollenVisual, gameObject.layer);
	}
	
	private static void SetLayerRecursively(Component a_rComponent, int a_iLayerNumber)
	{
		foreach(Transform oTransform in a_rComponent.GetComponentsInChildren<Transform>(true))
		{
			oTransform.gameObject.layer = a_iLayerNumber;
		}
	}
}
