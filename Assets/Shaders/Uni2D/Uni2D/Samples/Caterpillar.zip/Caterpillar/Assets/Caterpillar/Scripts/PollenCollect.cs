using UnityEngine;
using System.Collections;

public class PollenCollect : MonoBehaviour
{	
	public Vector2 collectPosition;
	
	public Vector2 collectStartVelocity;
	
	public Transform collectTarget;
	
	public PollenCounter pollenCounter;
	
	public int numberOfPollenToCollect;
	
	public float pollenCollectRate;
	
	public float collectDuration;
	
	private int m_iCollectCount = 0;
	
	private void Start()
	{
		NextCollect();
		if(numberOfPollenToCollect > 1)
		{
			InvokeRepeating("NextCollect", pollenCollectRate, pollenCollectRate);
		}
	}
	
	private void NextCollect()
	{
		StartCollect();
		++m_iCollectCount;
		
		if(m_iCollectCount >= numberOfPollenToCollect)
		{
			Destroy(this);
		}
	}
	
	private void StartCollect()
	{
		PollenCollectFx oPollenCollectFx = Instantiate(ItemFactory.Instance.pollenCollectFxPrefab) as PollenCollectFx;
		oPollenCollectFx.transform.position = collectPosition;
		oPollenCollectFx.collectDuration = collectDuration;
		oPollenCollectFx.StartCollect(collectStartVelocity, collectTarget, OnCollectEnd);
	}
	
	private void OnCollectEnd()
	{
		SoundPlayer_Pollen_Collect.Instance.PlayPollenEndCollectSound();
		pollenCounter.Add(1);
	}
}