using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundManager : MonoBehaviour
{	
	private float m_fMasterVolume = 1.0f;
	
	private AudioSource m_oSoundAudioSource;
	
	private static SoundManager ms_oInstance;
	
	public float MasterVolume
	{
		get
		{
			return m_fMasterVolume;
		}
		
		set
		{
			m_fMasterVolume = value;
		}
	}
	
	public static SoundManager Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlaySound(AudioClip a_rSound, float a_fVolume = 1.0f)
	{
		m_oSoundAudioSource.PlayOneShot(a_rSound, a_fVolume * MasterVolume);
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
		
		m_oSoundAudioSource = gameObject.AddComponent<AudioSource>();
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private void LateUpdate()
	{
		m_oSoundAudioSource.volume = MasterVolume;
	}
}
