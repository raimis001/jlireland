using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameOverPanel : MonoBehaviour
{
	private void Awake()
	{
		GameSequence.Instance.onStateChange += OnStateChange;
		Activate(false);
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
	}
	
	private void OnStateChange()
	{
		if(GameSequence.Instance.State == GameSequence.EState.GameOver)
		{
			Activate(true);
		}
	}
	
	private void Activate(bool a_bActivate)
	{
		gameObject.SetActive(a_bActivate);
	}
}
