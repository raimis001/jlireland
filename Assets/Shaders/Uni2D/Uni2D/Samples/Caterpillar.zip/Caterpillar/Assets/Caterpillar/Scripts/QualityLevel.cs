using UnityEngine;
using System.Collections;

public class QualityLevel : MonoBehaviour
{	
	public enum EQuality
	{
		Good,
		Highest
	}
	
	public bool overrideQualityInEditor;
	public EQuality editorQualityOverride;
	
	private static QualityLevel ms_oInstance;
	
	private EQuality m_eQuality;
	
	public EQuality Quality
	{
		get
		{
			#if UNITY_EDITOR
			if(overrideQualityInEditor)
			{
				return editorQualityOverride;
			}
			#endif
			return m_eQuality;
		}
	}
	
	public static QualityLevel Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
		
		m_eQuality = GetQuality();
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private EQuality GetQuality()
	{
		EQuality eQuality = EQuality.Highest;
		
		#if !UNITY_EDITOR
			#if UNITY_IPHONE
			eQuality = EQuality.Good;
			switch(iPhone.generation)
			{
				case iPhoneGeneration.iPhone5:
				case iPhoneGeneration.iPhone5C:
				case iPhoneGeneration.iPhone5S:
				case iPhoneGeneration.iPhoneUnknown:
				case iPhoneGeneration.iPad4Gen:
				case iPhoneGeneration.iPad5Gen:
				case iPhoneGeneration.iPadUnknown:
				case iPhoneGeneration.iPadMini2Gen:
				{
					eQuality = EQuality.Highest;
				}
				break;
			}
			#elif UNITY_ANDROID
			eQuality = EQuality.Good;
			#endif
		#endif
		
		return eQuality;
	}
}
