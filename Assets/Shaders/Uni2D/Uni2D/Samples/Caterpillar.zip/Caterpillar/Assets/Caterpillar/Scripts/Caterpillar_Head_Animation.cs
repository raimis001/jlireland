﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_Head_Animation : MonoBehaviour
{
	public Caterpillar_Head caterpillarHead;
	
	public Caterpillar caterpillar;
	
	public Caterpillar_GravityCenter gravityCenter;
	
	public float jumpAnimationDuration = 0.2f;
	
	public float eatAnimationDuration = 0.2f;
	
	public float wideOpenEyeFallVelocityMin = 2.0f;
	
	public float screamFallVelocityMin = 4.0f;
	
	public float blinkRateMin = 1.0f;
	public float blinkRateMax = 2.0f;
	
	private bool m_bSleep = false;
	
	// Blink
	private bool m_bBlinkAnimation;
	private float m_fBlinkAnimationTime;
	
	// Eat
	private bool m_bEatAnimation;
	private float m_fEatAnimationTime;
	
	// Blink
	private float m_fTimeBeforeNextBlink;
	
	private bool m_bWasGrounded;
	
	private bool m_bScreaming;
	
	private void Awake()
	{
		GameSequence.Instance.onStateChange += OnStateChange;
		OnStateChange();
		Pollen.onPollenPickedUpGlobal += OnPollenPickedUpGlobal;
		Caterpillar_BodyPart.onBodyPartCollisionEnter += OnBodyPartCollisionEnter;
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
		Pollen.onPollenPickedUpGlobal -= OnPollenPickedUpGlobal;
		Caterpillar_BodyPart.onBodyPartCollisionEnter -= OnBodyPartCollisionEnter;
	}
	
	private void Update()
	{
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		UpdateBlinkTimer();
		
		caterpillarHead.eye = Caterpillar_Head.EEyeState.Open;
		caterpillarHead.mouth = Caterpillar_Head.EMouthState.Close;
		
		// Grounded state change check
		bool bIsGrounded = caterpillar.IsGrounded;
		if(bIsGrounded && m_bWasGrounded == false)
		{
			// Blink on land
			StartBlinkAnimation();
		}
		m_bWasGrounded = bIsGrounded;
		
		// Blink animation
		if(m_bBlinkAnimation)
		{
			UpdateBlinkAnimation();
		}
		
		// Eat animation
		if(m_bEatAnimation)
		{
			UpdateEatAnimation();
		}
		
		if(bIsGrounded == false)
		{
			// Fall animation
			Vector2 f2Velocity = gravityCenter.Velocity;
			if(f2Velocity.y < 0.0f)
			{
				ResetBlinkTimer();
				bool bWasScreaming = m_bScreaming;
				m_bScreaming = false;
				if(f2Velocity.y < -wideOpenEyeFallVelocityMin)
				{
					caterpillarHead.eye = Caterpillar_Head.EEyeState.WideOpen;
				}
				if(f2Velocity.y < -screamFallVelocityMin)
				{
					caterpillarHead.mouth = Caterpillar_Head.EMouthState.Open;
					if(bWasScreaming == false)
					{
						SoundPlayer_Caterpillar.Instance.PlayFall();
					}
					m_bScreaming = true;
				}
				
			}
		}
	}
	
	// Blink
	private void StartBlinkAnimation()
	{
		m_fBlinkAnimationTime = 0.0f;
		m_bBlinkAnimation = true;
		ResetBlinkTimer();
	}
	
	private void StopBlinkAnimation()
	{
		m_fBlinkAnimationTime = 0.0f;
		m_bBlinkAnimation = false;
	}
	
	private void UpdateBlinkAnimation()
	{
		m_fBlinkAnimationTime += Time.deltaTime;
		if(m_fBlinkAnimationTime < jumpAnimationDuration)
		{
			caterpillarHead.eye = Caterpillar_Head.EEyeState.Close;
		}
		else
		{
			StopBlinkAnimation();
		}
	}
	
	// Eat
	private void StartEatAnimation()
	{
		m_fEatAnimationTime = 0.0f;
		m_bEatAnimation = true;
	}
	
	private void StopEatAnimation()
	{
		m_fEatAnimationTime = 0.0f;
		m_bEatAnimation = false;
	}
	
	private void UpdateEatAnimation()
	{
		m_fEatAnimationTime += Time.deltaTime;
		if(m_fEatAnimationTime < eatAnimationDuration)
		{
			caterpillarHead.mouth = Caterpillar_Head.EMouthState.Open;
		}
		else
		{
			StopEatAnimation();
		}
	}
	
	private void OnStateChange()
	{
		if(GameSequence.Instance.State == GameSequence.EState.PlayGame)
		{
			Sleep(false);
		}
		else
		{
			Sleep(true);
		}
	}
	
	private void Sleep(bool a_bSleep)
	{
		if(m_bSleep != a_bSleep)
		{
			ResetBlinkTimer();
			m_bSleep = a_bSleep;
			if(m_bSleep)
			{				
				caterpillarHead.mouth = Caterpillar_Head.EMouthState.Close;
				caterpillarHead.eye = Caterpillar_Head.EEyeState.Close;
			}
			else
			{
				caterpillarHead.mouth = Caterpillar_Head.EMouthState.Close;
				caterpillarHead.eye = Caterpillar_Head.EEyeState.Open;
			}
		}
	}
	
	private void OnPollenPickedUpGlobal(Pollen a_rPollen)
	{
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		StartEatAnimation();
	}
	
	private void OnBodyPartCollisionEnter(Caterpillar_BodyPart a_rBodyPart, Collision a_oCollision)
	{
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		if(a_oCollision.collider.gameObject.layer == LayerMask.NameToLayer("branch"))
		{
			return;
		}
		
		StartBlinkAnimation();
	}
	
	private void UpdateBlinkTimer()
	{
		m_fTimeBeforeNextBlink -= Time.deltaTime;
		if(m_fTimeBeforeNextBlink <= 0.0f)
		{
			StartBlinkAnimation();
		}
	}
	
	private void ResetBlinkTimer()
	{
		m_fTimeBeforeNextBlink = Random.Range(blinkRateMin, blinkRateMax);
	}
}
