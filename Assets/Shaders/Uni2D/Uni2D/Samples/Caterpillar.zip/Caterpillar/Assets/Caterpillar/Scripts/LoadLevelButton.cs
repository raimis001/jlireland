using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LoadLevelButton : MonoBehaviour
{	
	public Button button;
	
	public int levelIndex;
	
	private void Awake()
	{
		button.onButtonClick += OnButtonClick;
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonClick -= OnButtonClick;
		}
	}
	
	private void OnButtonClick()
	{
		LoadingManager.LoadLevel(levelIndex);
	}
}