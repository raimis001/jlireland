using UnityEngine;
using System.Collections;
using System;

[AddComponentMenu("Cosmophony/HUD/RatioManager")]
// RatioManager
public class RatioManager : MonoBehaviour
{	
	public static Action onResolutionChanged;
			
	// The ratio manager
	public Vector2 defaultRatio = new Vector2(3.0f, 2.0f);
	
	// The instance
	private static RatioManager ms_oInstance;
	
	private int m_iLastWidth;
	
	private int m_iLastHeight;
	
	// Default Ratio
	public Vector2 DefaultRatio
	{
		get
		{
			return defaultRatio;
		}
	}
	
	// Default Ratio
	public float DefaultWidthOnHeightRatio
	{
		get
		{
			return ComputeRatioWidthOnHeight(DefaultRatio);
		}
	}
	
	// Default Ratio
	public float DefaultHeightOnWidthRatio
	{
		get
		{
			return ComputeRatioHeightOnWidth(DefaultRatio);
		}
	}
	
	// Current Ratio
	public Vector2 CurrentRatio
	{
		get
		{
			return new Vector2(Screen.width, Screen.height);
		}
	}
	
	// Current Ratio
	public float CurrentWidthOnHeightRatio
	{
		get
		{
			return ComputeRatioWidthOnHeight(CurrentRatio);
		}
	}
				
	// Current Ratio
	public float CurrentHeightOnWidthRatio
	{
		get
		{
			return ComputeRatioHeightOnWidth(CurrentRatio);
		}
	}
	
	// Ratio Increase Width
	public float RatioIncreaseWidth
	{
		get
		{
			return CurrentWidthOnHeightRatio/DefaultWidthOnHeightRatio;
		}
	}
	
	// Ratio Increase Height
	public float RatioIncreaseHeight
	{
		get
		{
			return CurrentHeightOnWidthRatio/DefaultHeightOnWidthRatio;
		}
	}
	
	// Instance
	public static RatioManager Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void ForceResolutionChangeNotification()
	{
		OnResolutionChange();
	}
	
	//  Awake
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			DontDestroyOnLoad(ms_oInstance);
			ms_oInstance = this;
		}
		else
		{
			Destroy(gameObject);
			return;
		}
	}
	
	private void LateUpdate()
	{
		int iWidth = Screen.width;
		int iHeight = Screen.height;
		
		bool bResolutionChanged = false;
		
		if(iWidth != m_iLastWidth)
		{
			m_iLastWidth = iWidth;
			bResolutionChanged = true;
		}
		
		if(iHeight != m_iLastHeight)
		{
			m_iLastHeight = iHeight;
			bResolutionChanged = true;
		}
		
		if(bResolutionChanged)
		{
			OnResolutionChange();
		}
	}
	
	private void OnResolutionChange()
	{
		if(onResolutionChanged != null)
		{
			onResolutionChanged();
		}
	}
	
	// Compute Ratio Width On Height
	private float ComputeRatioWidthOnHeight(Vector2 a_f2Ratio)
	{
		return 	a_f2Ratio.x/a_f2Ratio.y;
	}
	
	// Compute Ratio Height on Width 
	private float ComputeRatioHeightOnWidth(Vector2 a_f2Ratio)
	{
		return 	a_f2Ratio.y/a_f2Ratio.x;
	}
}