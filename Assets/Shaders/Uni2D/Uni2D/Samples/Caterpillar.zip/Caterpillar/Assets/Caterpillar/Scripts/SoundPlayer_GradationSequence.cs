using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_GradationSequence : MonoBehaviour
{	
	public AudioClip[] sounds;
	
	public bool loop = false;
	
	public float startDecreaseLatency = 1.0f;
	
	public float indexDecreaseVelocity = 3.0f;
	
	public float volume = 1.0f;
	
	private float m_fSoundIndex = -1.0f;
	
	private float m_fTimeBeforeDecrease;
	
	public void PlaySound()
	{
		m_fTimeBeforeDecrease = startDecreaseLatency;
		
		// Next index
		int iNextIndex = Mathf.RoundToInt(m_fSoundIndex) + 1;
		if(iNextIndex < 0)
		{
			iNextIndex = 0;
		}
		else if(iNextIndex >= sounds.Length)
		{
			if(loop)
			{
				iNextIndex = 0;
			}
			else
			{
				iNextIndex = sounds.Length - 1;
			}
		}
		
		if(sounds.Length > 0)
		{
			SoundManager.Instance.PlaySound(sounds[iNextIndex], volume);
		}
		m_fSoundIndex = iNextIndex;
	}
	
	private void Update()
	{
		if(m_fTimeBeforeDecrease > 0.0f)
		{
			m_fTimeBeforeDecrease -= Time.deltaTime;
		}
		else
		{
			if(indexDecreaseVelocity < 0.0f)
			{
				m_fSoundIndex = -1.0f;
			}
			else
			{
				m_fSoundIndex -= indexDecreaseVelocity * Time.deltaTime;
				if(m_fSoundIndex < -1.0f)
				{	
					m_fSoundIndex = -1.0f;
				}
			}
		}
	}
}
