﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SubWave : MonoBehaviour
{
	public Wave wave;
	
	private bool m_bSubWaveInProgress = true;
	
	public bool SubWaveInProgress
	{
		get
		{
			return m_bSubWaveInProgress;
		}
	}
	
	protected void SubWaveEnd()
	{
		if(m_bSubWaveInProgress)
		{
			wave.Unregister(this);
			m_bSubWaveInProgress = false;
		}
	}
	
	protected virtual void Awake()
	{
		wave.Register(this);
	}
}
