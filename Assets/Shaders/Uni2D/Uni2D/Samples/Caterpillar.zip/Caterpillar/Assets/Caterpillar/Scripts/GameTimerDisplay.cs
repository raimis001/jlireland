using UnityEngine;
using System.Collections;
using System;

public class GameTimerDisplay : MonoBehaviour
{
	public TextMesh textMesh;
	
	private void LateUpdate()
	{
		TimeSpan oTimeSpan = TimeSpan.FromSeconds(GameTimer.Instance.GameTimeRemaining);
		
		string oTimerDisplayText = string.Format("{0:D2}:{1:D2}", oTimeSpan.Minutes, oTimeSpan.Seconds);
		
		textMesh.text = oTimerDisplayText;
	}
}
