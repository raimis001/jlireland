using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraAnimation : MonoBehaviour
{
	public Animator cameraAnimator;
	
	private void Awake()
	{
		GameSequence.Instance.onStateChange += OnStateChange;
		OnStateChange();
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
	}
	
	private void OnStateChange()
	{
		switch(GameSequence.Instance.State)
		{
			case GameSequence.EState.Introduction:
			{
				PlayAnimation("introduction");
			}
			break;
			
			case GameSequence.EState.GameOver:
			{
				PlayAnimation("gameOver");
			}
			break;
		}
	}
	
	private void PlayAnimation(string a_oAnimationName)
	{
		cameraAnimator.Play(a_oAnimationName);
	}
}
