﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Branch_SurfaceNoise : MonoBehaviour 
{	
	public float noiseHeight = 0.001f;
	
	private void Awake()
	{
		Uni2DSprite rSprite = GetComponent<Uni2DSprite>();
		Uni2DMesh2D rMesh2D = rSprite.SpriteData.mesh2D;		
		foreach(Uni2DMeshShape2D shape in rMesh2D.shapes)
		{
			Vector2[] rVertices = shape.vertices;
			for(int i = 0; i < rVertices.Length; ++i)
			{
				Vector2 f2Vertex = rVertices[i];
				f2Vertex.y += noiseHeight * ((i%2 == 0)?-1.0f:1.0f);
				rVertices[i] = f2Vertex;
			}
		}
		
		rSprite.Skinning.UpdatePhysicsSkinning();
	}
}
