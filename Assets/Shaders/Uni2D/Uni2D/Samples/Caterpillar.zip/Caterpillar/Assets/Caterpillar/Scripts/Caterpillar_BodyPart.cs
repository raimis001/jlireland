﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_BodyPart : MonoBehaviour
{
	public static System.Action<Caterpillar_BodyPart, Collision> onBodyPartCollisionEnter;
	
	public float top = 100.0f;
	
	public float canJumpTolerance = 0.1f;
	
	public Caterpillar caterpillar;
	
	private bool m_bIsGrounded;
	
	private float m_fPenetrationBeforeBranchUpdate;
	
	private float m_fPenetrationAfterBranchUpdate;
	
	public bool IsGrounded
	{
		get
		{
			return m_bIsGrounded;
		}
	}
	
	public Vector2 Velocity
	{
		get
		{
			if(rigidbody2D != null)
			{
				return rigidbody2D.velocity;
			}
			
			return rigidbody.velocity;
		}
		
		set
		{
			if(rigidbody2D != null)
			{
				rigidbody2D.velocity = value;
			}
			else
			{
				rigidbody.velocity = value;
			}
		}
	}
	
	public Vector2 Position
	{
		get
		{
			if(rigidbody2D != null)
			{
				return rigidbody2D.position;
			}
			
			return rigidbody.position;
		}
		
		set
		{
			if(rigidbody2D != null)
			{
				rigidbody2D.position = value;
			}
			else
			{
				rigidbody.position = value;
			}
		}
	}
	
	private float Radius
	{
		get
		{
			CircleCollider2D rCircleCollider2D = collider2D as CircleCollider2D;
			if(rCircleCollider2D != null)
			{
				return rCircleCollider2D.radius;
			}
			
			return (collider as SphereCollider).radius;
		}
	}
	
	private Vector2 Center
	{
		get
		{
			CircleCollider2D rCircleCollider2D = collider2D as CircleCollider2D;
			if(rCircleCollider2D != null)
			{
				return rCircleCollider2D.center;
			}
			
			return (collider as SphereCollider).center;
		}
	}
	
	public void AddForce(Vector2 a_f2Force)
	{
		if(rigidbody2D != null)
		{
			rigidbody2D.AddForce(a_f2Force);
		}
		else
		{
			rigidbody.AddForce(a_f2Force);
		}
	}
	
	public void JumpOnTopOfNut()
	{
		caterpillar.JumpOnTopOfNut();
	}
	
	public void BeforeBranchUpdate()
	{
		m_fPenetrationBeforeBranchUpdate = GetPenetration();
	}
	
	public float GetPenetrationAfterBranchUpdate()
	{
		m_fPenetrationAfterBranchUpdate = GetPenetration() - m_fPenetrationBeforeBranchUpdate;
		return m_fPenetrationAfterBranchUpdate;
	}
	
	public void MoveFromGround(float a_fMovement)
	{
		if(a_fMovement > 0.0f)
		{
			//a_fMovement *= 2.0f;
			Position += Vector2.up * a_fMovement;
			
			//rigidbody.AddForce(-Vector3.up * a_fMovement/(Time.fixedDeltaTime * Time.fixedDeltaTime));
			//rigidbody.velocity -= Vector3.up * a_fMovement/Time.fixedDeltaTime;
			
			if(m_fPenetrationAfterBranchUpdate >= caterpillar.penetrationVelocityMax)
			{
				Vector2 f2Velocity = Velocity;
				f2Velocity.y = 0.0f;
				Velocity = f2Velocity;
			}
		}
	}
	
	private void OnCollisionEnter(Collision a_oCollision)
	{
		if(onBodyPartCollisionEnter != null)
		{
			onBodyPartCollisionEnter(this, a_oCollision);
		}
	}
	
	private float GetPenetration()
	{
		float fPenetration = GetSignPenetration();
		
		if(fPenetration <= 0.0f)
		{
			fPenetration = 0.0f;	
		}
		
		return fPenetration;
	}
	
	private float GetSignPenetration()
	{
		float fGroundHeight = GetGroundHeight();
		float fBottomHeight = GetCenter().y - Radius * transform.lossyScale.y;
		
		return fGroundHeight - fBottomHeight;
	}
	
	private void FixedUpdate()
	{
		m_bIsGrounded = false;
		if(GetSignPenetration() > -canJumpTolerance)
		{
			m_bIsGrounded = true;
		}
	}
	
	private float GetGroundHeight()
	{		
		Vector2 f2Top = GetCenter();
		f2Top.y = top;
		
		if(rigidbody2D != null)
		{
			RaycastHit2D oHit = Physics2D.Raycast(f2Top, -Vector2.up, float.PositiveInfinity, 1 << LayerMask.NameToLayer("branch"));
			
			return oHit.point.y;
		}
		else
		{
			RaycastHit oHit;
			Physics.Raycast(f2Top, -Vector2.up, out oHit, float.PositiveInfinity, 1 << LayerMask.NameToLayer("branch"));
			
			return oHit.point.y;
		}
	}
	
	private Vector2 GetCenter()
	{		
		return (Vector2)transform.TransformPoint(Center);
	}
}
