using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class NextLevelButton : MonoBehaviour
{	
	public Button button;
	
	private void Awake()
	{
		button.onButtonClick += OnButtonClick;
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonClick -= OnButtonClick;
		}
	}
	
	private void OnButtonClick()
	{
		int iNextLevelIndex = (Application.loadedLevel + 1) % Application.levelCount;
		LoadingManager.LoadLevel(iNextLevelIndex);
	}
}