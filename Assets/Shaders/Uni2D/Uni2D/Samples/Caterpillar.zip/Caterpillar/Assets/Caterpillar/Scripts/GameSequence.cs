using UnityEngine;
using System.Collections;

public class GameSequence : MonoBehaviour
{
	public enum EState
	{
		Introduction,
		PlayGame,
		GameOver
	}
	
	public System.Action onStateChange;
	
	public void PlayGame()
	{
		NextState(EState.PlayGame);
	}
	
	public void GameOver()
	{
		NextState(EState.GameOver);
	}
	
	private EState m_eState;
	
	private static GameSequence ms_oInstance;
	
	public EState State
	{
		get
		{
			return m_eState;
		}
	}
	
	public static GameSequence Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void Start()
	{
		SetState(EState.Introduction);
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private void NextState(EState a_eState)
	{
		if((int)a_eState == (int)m_eState + 1)
		{
			SetState(a_eState);
		}
	}
	
	private void SetState(EState a_eState)
	{
		m_eState = a_eState;
		OnStateChange();
	}
	
	private void OnStateChange()
	{
		if(onStateChange != null)
		{
			onStateChange();
		}
	}
}
