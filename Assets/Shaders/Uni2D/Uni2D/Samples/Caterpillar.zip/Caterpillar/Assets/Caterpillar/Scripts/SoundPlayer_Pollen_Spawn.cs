using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Pollen_Spawn : MonoBehaviour
{	
	public AudioClip pollenSpawn;
	
	public float pollenSpawnVolume = 0.3f;
	
	private static SoundPlayer_Pollen_Spawn ms_oInstance;
	
	public static SoundPlayer_Pollen_Spawn Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlayPollenSpawnSound()
	{
		SoundManager.Instance.PlaySound(pollenSpawn, pollenSpawnVolume);
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
