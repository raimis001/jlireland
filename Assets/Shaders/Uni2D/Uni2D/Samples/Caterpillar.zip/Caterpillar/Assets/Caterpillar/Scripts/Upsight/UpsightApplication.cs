using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UpsightApplication : MonoBehaviour
{
	public string androidAppToken;
	public string androidAppSecret;
	public string iosAppToken;
	public string iosAppSecret;
	
	#if UNITY_ANDROID || UNITY_IPHONE
	private static UpsightApplication ms_oInstance;
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
			DontDestroyOnLoad(ms_oInstance);
		}
		else
		{
			Destroy(gameObject);
			return;
		}
	}
	
	private void Start()
	{
		#if UNITY_ANDROID
		Upsight.init( androidAppToken, androidAppSecret );
		#else
		Upsight.init( iosAppToken, iosAppSecret );
		#endif
		
		// Make an open request at every app launch
		Upsight.requestAppOpen();
	}
	
	private void OnApplicationPause( bool pauseStatus )
	{
		// Make an open request whenever app is resumed
		if( !pauseStatus )
			Upsight.requestAppOpen();
	}
	#endif
}
