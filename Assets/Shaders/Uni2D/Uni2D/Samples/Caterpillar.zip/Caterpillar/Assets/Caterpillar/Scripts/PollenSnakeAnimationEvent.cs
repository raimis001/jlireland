using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PollenSnakeAnimationEvent : MonoBehaviour
{
	public PollenSnake pollenChain;
	
	public void StartSpawn()
	{
		pollenChain.StartSpawn();
	}
	
	public void PollenChainEnd()
	{
		pollenChain.PollenChainEnd();
	}
}
