﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Wave : MonoBehaviour
{
	public WaveSequencer waveSequencer;
	
	private List<SubWave> m_rSubWaves = new List<SubWave>();
	
	public void Register(SubWave a_rSubWave)
	{
		m_rSubWaves.Add(a_rSubWave);
	}
	
	public void Unregister(SubWave a_rSubWave)
	{
		if(m_rSubWaves.Count > 0)
		{
			m_rSubWaves.Remove(a_rSubWave);
			if(m_rSubWaves.Count <= 0)
			{
				waveSequencer.WaveEnd(this);
			}
		}
	}
}
