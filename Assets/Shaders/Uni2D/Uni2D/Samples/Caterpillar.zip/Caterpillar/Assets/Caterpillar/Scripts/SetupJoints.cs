﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SetupJoints : MonoBehaviour
{	
	public float gravityScale = 1.0f;
	
	public float angularDrag = 0.0f;
	
	public float frequency = 20.0f;
	
	public float dampingRatio = 0.25f;
	
	public float hingeAngle = 10.0f;
	
	public bool useHingeLimit = true;
	
	public bool enableSpringJoints = true;
	
	public bool enableHingeJoints = true;
	
	private SpringJoint2D[] m_rSpringJoints;
	
	private HingeJoint2D[] m_rHingeJoints;
	
	private void Awake()
	{
		m_rSpringJoints = GetComponentsInChildren<SpringJoint2D>();
		m_rHingeJoints = GetComponentsInChildren<HingeJoint2D>();
	}
	
	private void FixedUpdate()
	{
		foreach(SpringJoint2D rJoint in m_rSpringJoints)
		{
			rJoint.rigidbody2D.gravityScale = gravityScale;
			rJoint.rigidbody2D.angularDrag = angularDrag;
			
			//rJoint.enabled = enableSpringJoints;
			rJoint.frequency = frequency;
			rJoint.dampingRatio = dampingRatio;
		}
		
		foreach(HingeJoint2D rJoint in m_rHingeJoints)
		{
			JointAngleLimits2D oLimits = rJoint.limits;
			
			oLimits.min = -hingeAngle;
			oLimits.max = hingeAngle;
			
			rJoint.limits = oLimits;
			
			rJoint.useLimits = useHingeLimit;
			
			rJoint.enabled = enableHingeJoints;
		}
	}
}
