using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FadeTransition : MonoBehaviour
{
	public SpriteRenderer fadeMaskSpriteRenderer;
	
	public float smoothTime = 0.5f; 
	
	public float reachDistance = 0.01f;
	
	private float m_fFadeTarget;
	
	private bool m_bFading;

	private float m_fFadeVelocity;
	
	private System.Action m_rOnFadeEnd;
	
	public void SetAlpha(float a_fAlpha)
	{
		Color oColor = fadeMaskSpriteRenderer.color;
		oColor.a = a_fAlpha;
		fadeMaskSpriteRenderer.color = oColor;
		
		// Quick hack to have the game sound fade on scene quit
		if(m_fFadeTarget == 1.0f)
		{
			if(SoundManager.Instance != null)
			{
				SoundManager.Instance.MasterVolume = (1.0f - a_fAlpha);
			}
		}
		
		if(a_fAlpha <= 0.0f)
		{
			fadeMaskSpriteRenderer.enabled = false;
		}
		else
		{
			fadeMaskSpriteRenderer.enabled = true;
		}
	}
	
	public void StartFade(float a_fFadeTarget, System.Action a_rOnFadeEnd = null)
	{
		m_fFadeTarget = a_fFadeTarget;
		m_bFading = true;
		
		m_rOnFadeEnd = a_rOnFadeEnd;
	}
	
	private void Awake()
	{
		SetAlpha(0.0f);
	}
	
	private void Update()
	{
		if(m_bFading)
		{
			float fAlpha = GetAlpha();
			
			fAlpha = Mathf.SmoothDamp(fAlpha, m_fFadeTarget, ref m_fFadeVelocity, smoothTime);
			
			if(Mathf.Abs(fAlpha - m_fFadeTarget) <= reachDistance)
			{
				m_bFading = false;
				m_fFadeVelocity = 0.0f;	
				fAlpha = m_fFadeTarget;
				if(m_rOnFadeEnd != null)
				{
					m_rOnFadeEnd();
					m_rOnFadeEnd = null;
				}
			}
			
			SetAlpha(fAlpha);
		}
	}
	
	private float GetAlpha()
	{
		return fadeMaskSpriteRenderer.color.a;
	}
}
