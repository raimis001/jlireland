﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PollenSpawnSequence : MonoBehaviour
{
	public bool reverse = false;
	
	public List<PollenSpawnPoint> pollenSpawnPoints;
	
	public float startDelay = 0.0f;
	
	public float spawnDelay = 0.5f;
	
	public float spawnRate = 0.25f;
	
	private int m_iNextSpawnIndex = 0;
	private int m_iNextPreSpawnIndex = 0;
	
	private PollenChain m_oPollenChain;
	
	private List<PollenPreSpawnFx> m_oPreSpawnFxs = new List<PollenPreSpawnFx>();
			
	private void Awake()
	{
		m_oPollenChain = PollenChain.CreatePollenChain(gameObject);
		foreach(PollenSpawnPoint rPollenSpawnPoint in pollenSpawnPoints)
		{
			PollenPreSpawnFx oPreSpawnFx = PollenPreSpawnFx.CreatePollenPreSpawnFX(rPollenSpawnPoint.gameObject);
			m_oPreSpawnFxs.Add(oPreSpawnFx);
		}
	}
	
	private void Start()
	{
		for(int i = 0; i < pollenSpawnPoints.Count; ++i)
		{
			Invoke("PreSpawn", i * spawnRate + startDelay);
		}
	}
	
	private void OnDrawGizmos()
	{
		if(pollenSpawnPoints == null)
		{
			return;
		}
		
		foreach(PollenSpawnPoint rSpawnPoint in pollenSpawnPoints)
		{
			if(rSpawnPoint == null)
			{
				continue;
			}
			
			Gizmos.color = Color.yellow;
			Gizmos.DrawWireSphere(rSpawnPoint.transform.position, 1.25f);
		}
	}
	
	private void PreSpawn()
	{
		int iPlayIndex = GetPlayIndex(m_iNextPreSpawnIndex);
		
		PollenPreSpawnFx rPreSpawnFx = m_oPreSpawnFxs[iPlayIndex];
		rPreSpawnFx.StartFx();
		++m_iNextPreSpawnIndex;
		
		Invoke("Spawn", spawnDelay);
	}
	
	private void Spawn()
	{
		int iPlayIndex = GetPlayIndex(m_iNextSpawnIndex);
		
		PollenPreSpawnFx rPreSpawnFx = m_oPreSpawnFxs[iPlayIndex];
		rPreSpawnFx.StopFx();
		
		PollenSpawnPoint rPollenSpawnPoint = pollenSpawnPoints[iPlayIndex];
			
		Pollen oPollen = rPollenSpawnPoint.Spawn();
		
		if(oPollen != null)
		{
			m_oPollenChain.AddPollen(oPollen);
		}
		
		++m_iNextSpawnIndex;
	}
	
	private int GetPlayIndex(int a_iIndex)
	{
		if(reverse)
		{
			return pollenSpawnPoints.Count - 1 - a_iIndex;
		}
		else
		{
			return a_iIndex;
		}
	}
}
