﻿using UnityEngine;
using System.Collections;

public class PollenVisualColor : MonoBehaviour
{
	public PollenVisualSpawner pollenVisualSpawner;
	
	public Color color = Color.white;
	
	private void LateUpdate()
	{
		if(color != pollenVisualSpawner.PollenVisual.Color)
		{
			pollenVisualSpawner.PollenVisual.Color = color;
		}
	}
	
	private static void SetLayerRecursively(Component a_rComponent, int a_iLayerNumber)
	{
		foreach(Transform oTransform in a_rComponent.GetComponentsInChildren<Transform>(true))
		{
			oTransform.gameObject.layer = a_iLayerNumber;
		}
	}
}
