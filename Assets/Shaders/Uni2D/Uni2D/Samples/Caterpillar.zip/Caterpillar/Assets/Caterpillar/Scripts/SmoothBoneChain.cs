﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SmoothBoneChain : MonoBehaviour 
{
	public enum EChainOrientation
	{
		Right,
		Left,
		Up,
		Down
	}
	
	public EChainOrientation chainOrientation;
	
	private Uni2DSmoothBindingBone[] m_oBones;
	
	private void Awake()
	{
		m_oBones = GetComponentsInChildren<Uni2DSmoothBindingBone>();
	}
	
	private void FixedUpdate()
	{		
		AdjustBoneChainTangents();
	}
	
	private void AdjustBoneChainTangents()
	{
		for(int i = 0; i < m_oBones.Length; ++i)
		{
			Transform rBoneLeft = null;
			Transform rBoneMiddle = null;
			Transform rBoneRight = null;
			
			rBoneMiddle = m_oBones[i].transform;
			
			if(i > 0)
			{
				rBoneLeft = m_oBones[i-1].transform;
			}
			else
			{
				rBoneLeft = rBoneMiddle;
			}
			
			if(i < m_oBones.Length - 1)
			{
				rBoneRight = m_oBones[i+1].transform;
			}
			else
			{
				rBoneRight = rBoneMiddle;
			}

			Vector3 f3Direction = rBoneRight.position - rBoneLeft.position;
			
			switch(chainOrientation)
			{
				case EChainOrientation.Up:
				{
					rBoneMiddle.up = f3Direction;
				} 
				break;
				
				case EChainOrientation.Down:
				{
					rBoneMiddle.up = -f3Direction;
				} 
				break;
				
				case EChainOrientation.Left:
				{
					rBoneMiddle.right = -f3Direction;
				} 
				break;
			
				case EChainOrientation.Right:
				default:
				{
					rBoneMiddle.right = f3Direction;
				}
				break; 
			}
		}
	}
}
