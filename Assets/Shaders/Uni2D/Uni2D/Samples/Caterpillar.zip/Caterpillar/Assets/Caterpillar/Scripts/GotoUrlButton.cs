using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GotoUrlButton : MonoBehaviour
{	
	public Button button;
	
	public string url;
	
	private void Awake()
	{
		button.onButtonClick += OnButtonClick;
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonClick -= OnButtonClick;
		}
	}
	
	private void OnButtonClick()
	{
		Application.OpenURL(url);
	}
}