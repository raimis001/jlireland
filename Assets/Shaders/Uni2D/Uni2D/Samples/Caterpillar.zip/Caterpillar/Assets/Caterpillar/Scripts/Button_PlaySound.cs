using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Button_PlaySound : MonoBehaviour
{	
	private Button m_rButton;
	
	private void Awake()
	{
		m_rButton = GetComponent<Button>();
		
		m_rButton.onButtonDown += OnButtonDown;
		m_rButton.onButtonUp += OnButtonUp;
	}
	
	private void OnDestroy()
	{
		if(m_rButton != null)
		{
			m_rButton.onButtonDown -= OnButtonDown;
			m_rButton.onButtonUp -= OnButtonUp;
		}
	}
	
	private void OnButtonDown()
	{
		SoundPlayer_Button.Instance.PlayDown();
	}
	
	private void OnButtonUp()
	{
		SoundPlayer_Button.Instance.PlayUp();
	}
}