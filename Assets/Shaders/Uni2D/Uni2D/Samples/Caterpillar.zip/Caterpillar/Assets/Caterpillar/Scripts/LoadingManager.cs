using UnityEngine;
using System.Collections;

public class LoadingManager : MonoBehaviour
{
	public FadeTransition fadeTransition;
	
	private int m_iNextLevelIndex;
	
	private static LoadingManager ms_oInstance;
	
	public static LoadingManager Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public static void LoadLevel(int a_iLevelIndex)
	{
		if(ms_oInstance == null)
		{
			Application.LoadLevel(a_iLevelIndex);
		}
		else
		{
			ms_oInstance._LoadLevel(a_iLevelIndex);
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void Start()
	{
		if(fadeTransition != null)
		{
			fadeTransition.SetAlpha(1.0f);
			fadeTransition.StartFade(0.0f);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private void _LoadLevel(int a_iLevelIndex)
	{
		m_iNextLevelIndex = a_iLevelIndex;
		if(fadeTransition != null)
		{
			fadeTransition.StartFade(1.0f, GoToNextLevel);
		}
		else
		{
			GoToNextLevel();
		}
	}
	
	private void GoToNextLevel()
	{
		Application.LoadLevel(m_iNextLevelIndex);
	}
}
