using UnityEngine;
using System.Collections;

public class GameTimer : MonoBehaviour
{
	public float gameDuration = 120;
	
	private float m_fGameRemainingTime;
	
	private static GameTimer ms_oInstance;
	
	public float GameTimeRemaining
	{
		get
		{
			return m_fGameRemainingTime;
		}
	}
	
	public static GameTimer Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
		
		m_fGameRemainingTime = gameDuration;
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private void Update()
	{
		if(GameSequence.Instance.State == GameSequence.EState.PlayGame)
		{
			m_fGameRemainingTime -= Time.deltaTime;
			if(m_fGameRemainingTime <= 0.0f)
			{
				m_fGameRemainingTime = 0.0f;
				GameSequence.Instance.GameOver();
			}
		}
	}
}
