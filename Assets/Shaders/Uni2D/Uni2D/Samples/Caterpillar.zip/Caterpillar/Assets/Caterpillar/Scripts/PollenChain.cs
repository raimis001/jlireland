﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PollenChain : MonoBehaviour
{	
	private int m_iFirstInChainIndex = 0;
	private bool m_bChainInProgress = true;	
	
	private List<Pollen> m_oPollens = new List<Pollen>();
	
	public static PollenChain CreatePollenChain(GameObject a_rGameObject)
	{
		return a_rGameObject.AddComponent<PollenChain>();
	}
	
	public void AddPollen(Pollen a_rPollen)
	{
		if(m_bChainInProgress)
		{
			int iPollenIndex = m_oPollens.Count;
			m_oPollens.Add(a_rPollen);
		
			if(iPollenIndex == m_iFirstInChainIndex)
			{
				a_rPollen.DoubleGain();
			}
			a_rPollen.onPollenPickedUp += OnPollenPickedUp;
		}
	}
	
	private void OnPollenPickedUp(Pollen a_rPollen)
	{
		if(m_bChainInProgress)
		{
			for(int i = 0; i < m_oPollens.Count; ++i)
			{
				if(m_oPollens[i] == a_rPollen)
				{
					if(i == m_iFirstInChainIndex)
					{
						NextInChain();
						break;
					}
					else
					{
						StopChain();
					}
				}
			}
		}
	}
	
	private void NextInChain()
	{
		++m_iFirstInChainIndex;
		
		// Activate the next pollen if already spawned
		int iChainCount = m_oPollens.Count;
		if(m_iFirstInChainIndex >= 0 && m_iFirstInChainIndex < iChainCount)
		{
			m_oPollens[m_iFirstInChainIndex].DoubleGain();
		}
	}
	
	private void StopChain()
	{
		if(m_bChainInProgress)
		{
			m_bChainInProgress = false;
			foreach(Pollen rPollen in m_oPollens)
			{
				if(rPollen != null)
				{
					rPollen.CancelDoubleGain();
					rPollen.onPollenPickedUp -= OnPollenPickedUp;
				}
			}
		}
	}
}
