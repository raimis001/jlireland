﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Branch : MonoBehaviour 
{
	public class BoneTarget
	{
		public static System.Action<BoneTarget> onBoneTargetPick;
		
		private Branch m_rBranch;
		
		private Transform m_rBoneTransform;
		
		private float m_fPickZoneLeft;
		private float m_fPickZoneRight;
		
		private float m_fGoToTargetVelocity;
		private float m_fTargetHeight;
		
		private bool m_bMoveToTarget;
		
		public float Velocity
		{
			get
			{
				return m_fGoToTargetVelocity;
			}
		}
		
		public float TargetDistance
		{
			get
			{
				return Mathf.Abs(m_fTargetHeight - CurrentHeight); 
			}
		}
		
		private float CurrentHeight
		{
			get
			{
				return m_rBoneTransform.localPosition.y;
			}
		}
		
		public void Initialize(Branch a_rBranch, Transform a_rBoneLeft, Transform a_rBone, Transform a_rBoneRight, float a_fLeftPercent, float a_fRightPercent)
		{
			m_rBranch = a_rBranch;
			
			m_rBoneTransform = a_rBone;
			
			float fCenter = a_rBone.localPosition.x;
			float fLeft = a_rBoneLeft.localPosition.x;
			float fRight = a_rBoneRight.localPosition.x;
			
			if(a_rBoneLeft == a_rBone)
			{
				m_fPickZoneLeft = float.NegativeInfinity;
			}
			else
			{
				m_fPickZoneLeft = (fLeft - fCenter) * a_fLeftPercent + fCenter;
			}
			
			if(a_rBoneRight == a_rBone)
			{
				m_fPickZoneRight = float.PositiveInfinity;
			}
			else
			{
				m_fPickZoneRight = (fRight - fCenter) * a_fRightPercent + fCenter;
			}
		}
		
		public void Reset()
		{
			m_bMoveToTarget = false;
			m_fGoToTargetVelocity = 0.0f;
		}
		
		public void SelectTarget(Vector2 a_f2SelectionBegin, Vector2 a_f2SelectionEnd, bool a_bCursorWasDown)
		{
			bool bTargetSelected = false;
			float fTargetHeight = 0.0f;
			
			if(a_f2SelectionEnd.x < m_fPickZoneLeft)
			{
				if(a_f2SelectionBegin.x >= m_fPickZoneLeft)
				{
					bTargetSelected = true;
					float fPercent = (m_fPickZoneLeft - a_f2SelectionBegin.x)/(a_f2SelectionEnd.x - a_f2SelectionBegin.x);
					fTargetHeight = Mathf.Lerp(a_f2SelectionBegin.y, a_f2SelectionEnd.y, fPercent);
				}
			}
			else if(a_f2SelectionEnd.x > m_fPickZoneRight)
			{
				if(a_f2SelectionBegin.x <= m_fPickZoneRight)
				{
					bTargetSelected = true;
					float fPercent = (m_fPickZoneRight - a_f2SelectionBegin.x)/(a_f2SelectionEnd.x - a_f2SelectionBegin.x);
					fTargetHeight = Mathf.Lerp(a_f2SelectionBegin.y, a_f2SelectionEnd.y, fPercent);
				}
			}
			else
			{
				bTargetSelected = true;
				fTargetHeight = a_f2SelectionEnd.y;
			}
			
			if(bTargetSelected)
			{						
				float fOldTargetHeight = m_fTargetHeight;
				m_fTargetHeight = Mathf.Clamp(fTargetHeight, m_rBranch.minHeight, m_rBranch.maxHeight);
				float fCurrentHeight = CurrentHeight;
				
				float fOldMovementToTarget = fOldTargetHeight - fCurrentHeight;
				float fNewMovementToTarget = m_fTargetHeight - fCurrentHeight;
				if(fOldMovementToTarget * fNewMovementToTarget < 0)
				{
					m_fGoToTargetVelocity = 0.0f;
				}
				
				if(a_bCursorWasDown == false)
				{
					onBoneTargetPick(this);
				}
				m_bMoveToTarget = true;
			}
		}
		
		public bool CanBePicked(Vector2 a_f2Selection)
		{
			if(a_f2Selection.x >= m_fPickZoneLeft && a_f2Selection.x <= m_fPickZoneRight)
			{
				return true;
			}
			return false;
		}
		
		public void MoveBoneToTarget(float a_fSmoothTime)
		{
			if(m_bMoveToTarget)
			{
				Vector2 f2BonePosition = m_rBoneTransform.localPosition;
				
				float fLastTargetVelocity = m_fGoToTargetVelocity;
				float fHeight = Mathf.SmoothDamp(f2BonePosition.y, m_fTargetHeight, ref m_fGoToTargetVelocity, a_fSmoothTime);
				
				f2BonePosition.y = fHeight;
				
				if(Mathf.Abs(fHeight - m_fTargetHeight) <= m_rBranch.reachedTargetTreshold
				   || Mathf.Abs(m_fGoToTargetVelocity - fLastTargetVelocity) <= m_rBranch.stopVelocity)
				{
					Reset();
				}
				
				m_rBoneTransform.localPosition = f2BonePosition;
			}
		}
	}
	
	public float smoothTime = 1.0f;
	
	public float interBoneDistanceMax = 1.92f;
	
	public float minHeight = -1.0f;
	public float maxHeight = 1.0f;
	
	public float reachedTargetTreshold = 0.01f;
	
	public float stopVelocity = 0.01f;
	
	public bool updatePhysics = false;
	
	private Uni2DSmoothBindingBone[] m_oBones;
	private List<BoneTarget> m_oBoneTargets;
	
	private Transform m_rPickedBoneTransform;
	
	private Vector2 m_f2LastCursorPosition;
	
	private int m_iLastPickedBoneIndex = 0;
	
	private Uni2DSprite m_rSprite;
	
	private float m_fVelocity;
	
	private bool m_bCursorWasDown;
	
	public float Velocity
	{
		get
		{
			return m_fVelocity;
		}
	}
	
	private void Awake()
	{
		m_rSprite = GetComponent<Uni2DSprite>();
		m_oBones = GetComponentsInChildren<Uni2DSmoothBindingBone>();
		m_oBoneTargets = new List<BoneTarget>();
		for(int i = 0; i < m_oBones.Length; ++i)
		{
			BoneTarget oBoneTarget = new BoneTarget();
			
			Transform rBoneLeft = null;
			Transform rBoneMiddle = null;
			Transform rBoneRight = null;
			
			rBoneMiddle = m_oBones[i].transform;
			
			if(i > 0)
			{
				rBoneLeft = m_oBones[i-1].transform;
			}
			else
			{
				rBoneLeft = rBoneMiddle;
			}
			
			if(i < m_oBones.Length - 1)
			{
				rBoneRight = m_oBones[i+1].transform;
			}
			else
			{
				rBoneRight = rBoneMiddle;
			}
			
			float fLeftPercent = 1.0f;
			float fRightPercent = 1.0f;
			
			if(i == 0)
			{
				fRightPercent = 1.0f;
			}
			else if(i == 1)
			{
				fLeftPercent = 0.0f;
			}
			
			if(i == m_oBones.Length - 1)
			{
				fLeftPercent = 1.0f;
			}
			if(i == m_oBones.Length - 2)
			{
				fRightPercent = 0.0f;
			}
			
			oBoneTarget.Initialize(this, rBoneLeft, rBoneMiddle, rBoneRight, fLeftPercent, fRightPercent);
			m_oBoneTargets.Add(oBoneTarget);
		}
	}
	
	private void FixedUpdate()
	{		
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			m_fVelocity = 0.0f;
			return;
		}
		
		Camera rCamera = Camera.main;
		Vector2 f2CursorPosition = transform.InverseTransformPoint(rCamera.ScreenToWorldPoint(Input.mousePosition));
		
		if(Input.GetMouseButtonDown(0))
		{
			m_rPickedBoneTransform = null;
			m_f2LastCursorPosition = f2CursorPosition;
		}
		
		SmoothPick(f2CursorPosition, Input.GetMouseButton(0));
		
		if(Velocity != 0.0f)
		{
			updatePhysics = true;
			m_rSprite.Skinning.UpdatePhysicsSkinning();
		}
		else
		{
			updatePhysics = false;
		}
		
		m_f2LastCursorPosition = f2CursorPosition;
		UpdateVelocity();
	}
	
	private void UpdateVelocity()
	{
		float fVelocity = 0.0f;
		foreach(BoneTarget rBoneTarget in m_oBoneTargets)
		{
			fVelocity += rBoneTarget.Velocity;
		}
		
		m_fVelocity = fVelocity;
	}
	
	private void SmoothPick(Vector2 a_f2CursorPosition, bool a_bCursorDown)
	{
		if(a_bCursorDown)
		{
			// Compute the new targets
			foreach(BoneTarget rBoneTarget in m_oBoneTargets)
			{
				rBoneTarget.SelectTarget(m_f2LastCursorPosition, a_f2CursorPosition, m_bCursorWasDown);
			}
		}
			
		// Move All the bones to their targets
		foreach(BoneTarget rBoneTarget in m_oBoneTargets)
		{
			rBoneTarget.MoveBoneToTarget(smoothTime);
		}
		
		if(a_bCursorDown)
		{
			// Pick the nearest bone
			Transform rNearestBoneTransform = null;
			float fMinDistance = float.PositiveInfinity;
			int iPickedBoneIndex = 0;
			int iBoneIndex = 0;
			foreach(Uni2DSmoothBindingBone rBone in m_oBones)
			{
				if(m_oBoneTargets[iBoneIndex].CanBePicked(a_f2CursorPosition))
				{	
					Transform rBoneTransform = rBone.transform;
					Vector2 f2BonePosition = rBoneTransform.localPosition;
					Vector2 f2CursorToBone = f2BonePosition - a_f2CursorPosition;
					float fDistance = Mathf.Abs(f2CursorToBone.x);
					
					// Nearest bone yet?
					if(fDistance < fMinDistance)
					{
						fMinDistance = fDistance;
						rNearestBoneTransform = rBoneTransform;
						iPickedBoneIndex = iBoneIndex;
					}
				}
				
				iBoneIndex++;
			}
			if(m_rPickedBoneTransform != rNearestBoneTransform)
			{
				m_rPickedBoneTransform = rNearestBoneTransform;
			}
			m_iLastPickedBoneIndex = iPickedBoneIndex;
		}
		
		// Ensure the bones are from a limit distance from each other
		
		// Starting the solver from the picked bone
		
		// Solve the right side of the chain
		for(int i = m_iLastPickedBoneIndex + 1; i < m_oBones.Length; ++i)
		{
			ConstraintBoneDistance(i - 1, i);
		}
		
		// Then the left side
		for(int i = m_iLastPickedBoneIndex - 1; i >= 0; --i)
		{
			ConstraintBoneDistance(i + 1, i);
		}
		
		m_bCursorWasDown = a_bCursorDown;
	}
	
	private void ConstraintBoneDistance(int a_iPreviousBoneIndex, int a_iBoneIndex)
	{
		Transform rPreviousBoneTransform = m_oBones[a_iPreviousBoneIndex].transform;
		Transform rBoneTransform = m_oBones[a_iBoneIndex].transform;
		
		Vector2 f2PreviousBonePosition = rPreviousBoneTransform.localPosition;
		Vector2 f2BonePosition = rBoneTransform.localPosition;
		
		Vector2 f2FromPreviousBoneDistance = f2BonePosition - f2PreviousBonePosition;
		float fDistance = Mathf.Abs(f2FromPreviousBoneDistance.y);
		
		if(fDistance > interBoneDistanceMax)
		{
			f2FromPreviousBoneDistance.y *= interBoneDistanceMax/fDistance;
			f2BonePosition.y = f2PreviousBonePosition.y + f2FromPreviousBoneDistance.y;
			
			rBoneTransform.localPosition = f2BonePosition;
		}
	}
}
