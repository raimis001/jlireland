using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Shake : MonoBehaviour
{	
	public float shakeDuration;
	
	public float shakeRate;
	
	public float shakeAmplitude;
	
	public float shakeScale = 1.0f;
	
	public bool shakeX = true;
	
	public bool shakeY = true;
	
	public bool shakeZ = true;
	
	public Transform shakedTransform;
	
	public bool interpolate;
	
	private bool m_bShaking; 
	
	private Vector3 m_f3LastApplyShakedOffset;
	
	private float m_fShakingStartTime;
	
	private float m_fShakingInterpolationTime;
	
	private Vector3 m_f3NextShakedOffset;
	
	private Vector3 m_f3CurrentShakedOffset;
	
	private Vector3 m_f3LocalPositionBeforeShake;
	
	private bool m_bAskForExecuteShake;
	
	public void StartShake()
	{
		if(m_bShaking)
		{
			shakedTransform.localPosition = m_f3LocalPositionBeforeShake;
		}
		else
		{
			m_f3LocalPositionBeforeShake = shakedTransform.localPosition;
		}
		
		m_fShakingStartTime = Time.time;
		m_bShaking = true;
		
		m_f3LastApplyShakedOffset = Vector3.zero;
		m_f3CurrentShakedOffset = Vector3.zero;
		
		CancelInvoke("AskForExecuteShake");
		AskForExecuteShake();
		InvokeRepeating("AskForExecuteShake", shakeRate, shakeRate);
	}
	
	public void StopShake()
	{
		m_bShaking = false;
		
		shakedTransform.localPosition = m_f3LocalPositionBeforeShake;
		
		m_f3LastApplyShakedOffset = Vector3.zero;
		m_f3CurrentShakedOffset = Vector3.zero;
	}
	
	private void FixedUpdate()
	{
		if(m_bAskForExecuteShake)
		{
			ExecuteShake();
			m_bAskForExecuteShake = false;
		}
		
		if(m_bShaking && interpolate)
		{
			Vector3 f3ShakeMovement;
			Vector3 f3ShakeOffset;
			
			m_fShakingInterpolationTime += Time.deltaTime;
			
			f3ShakeOffset = Vector3.Lerp(m_f3CurrentShakedOffset, m_f3NextShakedOffset, m_fShakingInterpolationTime/shakeRate);
			
			f3ShakeMovement = f3ShakeOffset - m_f3LastApplyShakedOffset;
			
			shakedTransform.localPosition += f3ShakeMovement;
			
			m_f3LastApplyShakedOffset = f3ShakeOffset;
		}
	}
	
	private void AskForExecuteShake()
	{
		m_bAskForExecuteShake = true;
	}
	
	private void ExecuteShake()
	{
		float fShakingTime;
		
		// Update time
		fShakingTime = Time.time - m_fShakingStartTime;
		
		// If the shaking is terminated
		if(shakeDuration >= 0.0f && fShakingTime >= shakeDuration)
		{
			CancelInvoke("AskForExecuteShake");
			
			StopShake();
		}
		else
		{
			float fAmplitude;
	
			fAmplitude = ComputeShakeAmplitude();
			
			// Process the shaking
			m_f3CurrentShakedOffset = Vector3.zero;
			m_f3NextShakedOffset = ComputeRandomShakeDirection() * fAmplitude;
			
			// Reset interpolation time
			m_fShakingInterpolationTime = 0.0f;
			
			// If there is no interpolation
			if(interpolate == false)
			{
				shakedTransform.localPosition += m_f3NextShakedOffset - m_f3LastApplyShakedOffset;
				
				m_f3LastApplyShakedOffset = m_f3NextShakedOffset;
			}
		}
	}
	
	public float ComputeShakeAmplitude()
	{
		return shakeAmplitude * shakeScale;
	}
	
	Vector3 ComputeRandomShakeDirection()
	{
		int iShakeMode;
		Vector3 f3RandomDirection;
		
		// Initialize
		f3RandomDirection = Vector3.zero;
		
		// Get the shake mode
		iShakeMode = 0;
		iShakeMode += shakeX?1:0;
		iShakeMode += shakeY?1:0;
		iShakeMode += shakeZ?1:0;
		
		// Shake accordingly to the shake mode 
		if(iShakeMode >= 3)
		{
			f3RandomDirection = Random.onUnitSphere;	
		}
		else if(iShakeMode >= 2)
		{
			float fRandomOrientation;
			
			// Get a random planar rotation 
			fRandomOrientation = Random.Range(0.0f, 360.0f);
			
			if(shakeX == false)
			{
				f3RandomDirection.y = Mathf.Cos(fRandomOrientation); 
				f3RandomDirection.z = Mathf.Sin(fRandomOrientation);
			}
			else if(shakeY == false)
			{
				f3RandomDirection.x = Mathf.Cos(fRandomOrientation); 
				f3RandomDirection.z = Mathf.Sin(fRandomOrientation);
			}
			else if(shakeZ == false)
			{
				f3RandomDirection.x = Mathf.Cos(fRandomOrientation); 
				f3RandomDirection.y = Mathf.Sin(fRandomOrientation);
			}
		}
		else if(iShakeMode >= 1)
		{
			float fRandomOrientation;
			
			// Get a random linear orientation 
			fRandomOrientation = Mathf.Sign(Random.Range(-1.0f, 1.0f));
			
			if(shakeX)
			{
				f3RandomDirection.x = fRandomOrientation;
			}
			else if(shakeY)
			{
				f3RandomDirection.y = fRandomOrientation;
			}
			else if(shakeZ)
			{
				f3RandomDirection.z = fRandomOrientation;
			}
		}
		
		return f3RandomDirection;
	}
}