using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class StartPosition : MonoBehaviour
{
	public Transform copyTransform;

	private void Start()
	{
		transform.rotation = copyTransform.rotation;
		transform.position = copyTransform.position;
	}
}
