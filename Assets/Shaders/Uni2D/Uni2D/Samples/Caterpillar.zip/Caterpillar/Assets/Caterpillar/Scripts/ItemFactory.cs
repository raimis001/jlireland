using UnityEngine;
using System.Collections;

public class ItemFactory : MonoBehaviour
{
	public Pollen pollenPrefab;
	
	public PollenVisual pollenVisualPrefab;
	
	public PollenCollectFx pollenCollectFxPrefab;
	
	public PollenLoseFx pollenLoseFxPrefab;
	
	public Nut nutPrefab;
	
	public Nut_CollectFx nutCollectFxPrefab;
	
	public PollenPreSpawnFx pollenPreSpawnFxPrefab;
	
	private static ItemFactory ms_oInstance;
	
	public static ItemFactory Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
