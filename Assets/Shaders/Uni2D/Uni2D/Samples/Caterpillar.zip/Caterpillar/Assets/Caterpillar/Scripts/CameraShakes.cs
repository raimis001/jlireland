using UnityEngine;
using System.Collections;

public class CameraShakes : MonoBehaviour
{
	public Shake hitByNutShake;
	
	public Shake jumpOfTopOfNutShake;
	
	private static CameraShakes ms_oInstance;
	
	public static CameraShakes Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
