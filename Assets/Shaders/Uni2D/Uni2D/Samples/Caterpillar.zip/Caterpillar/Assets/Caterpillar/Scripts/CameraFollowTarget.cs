using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraFollowTarget : MonoBehaviour
{
	public Transform target;
	
	public float smoothTime = 0.5f; 
	
	public Vector2 maxDistanceFromTarget = new Vector2(200.0f, 200.0f);
	
	private Vector3 m_f3FollowVelocity;
	
	private void FixedUpdate()
	{
		Vector3 f3Position = transform.position;
		
		Vector2 f2TargetPosition = target.position;
		Vector2 f2Position = f3Position;
		
		f2Position.x = Mathf.Clamp(f2Position.x, f2TargetPosition.x - maxDistanceFromTarget.x, f2TargetPosition.x + maxDistanceFromTarget.x);
		f2Position.y = Mathf.Clamp(f2Position.y, f2TargetPosition.y - maxDistanceFromTarget.y, f2TargetPosition.y + maxDistanceFromTarget.y);
		
		Vector3 f3SmoothedPosition = Vector3.SmoothDamp(f2Position, f2TargetPosition, ref m_f3FollowVelocity, smoothTime);
		
		f3SmoothedPosition.z = f3Position.z;
		
		transform.position = f3SmoothedPosition;
	}
	
	private void OnDrawGizmos()
	{
		Vector2 f2Extent = maxDistanceFromTarget;
		Vector3 f3Offset = transform.position;
		f3Offset.z = 0.0f;
		Vector3 f3TopLeft = new Vector3(-f2Extent.x, f2Extent.y, 0) + f3Offset;
		Vector3 f3TopRight = new Vector3(f2Extent.x, f2Extent.y, 0) + f3Offset;
		Vector3 f3BottomRight = new Vector3(f2Extent.x, -f2Extent.y, 0) + f3Offset;
		Vector3 f3BottomLeft = new Vector3(-f2Extent.x, -f2Extent.y, 0) + f3Offset;
		
		Gizmos.color = Color.blue;
		
		Gizmos.DrawLine(f3TopLeft, f3TopRight);
		Gizmos.DrawLine(f3TopRight, f3BottomRight);
		Gizmos.DrawLine(f3BottomRight, f3BottomLeft);
		Gizmos.DrawLine(f3BottomLeft, f3TopLeft);
	}
}
