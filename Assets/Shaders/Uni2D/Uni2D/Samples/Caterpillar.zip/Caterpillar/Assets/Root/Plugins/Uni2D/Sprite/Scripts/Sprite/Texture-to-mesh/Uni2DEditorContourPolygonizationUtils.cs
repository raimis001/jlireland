#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public static class Uni2DEditorContourPolygonizationUtils
{
	public static List<Contour> MergeInnerAndOuterContours( List<Contour> a_rOuterContours, List<Contour> a_rInnerContours )
	{
		// Step 0: Sort the contours by region and their max x-value
		a_rOuterContours.Sort( );
		a_rInnerContours.Sort( );

		// Step 1: Insert every inner contours to corresponding outer contours
		List<Contour> oMergedContoursList = new List<Contour>( a_rOuterContours.Count );
		foreach( Contour rOuterContour in a_rOuterContours )
		{
			Contour rMergedContour = rOuterContour;

			// Loop over inner contours
			foreach( Contour rInnerContour in a_rInnerContours )
			{
				if( rInnerContour.Region == rMergedContour.Region )
				{
					// Insert inner contour into outer contour
					rMergedContour = Uni2DEditorPolygonTriangulationUtils.InsertInnerContourIntoOuterContour( rMergedContour, rInnerContour );
				}
				else if( rInnerContour.Region > rMergedContour.Region )	// inner contours are sorted by region...
				{
					break;	// ... so stop if inner contour region greater than outer contour region
				}
			}

			if( rMergedContour.Count > 2 )
			{
				oMergedContoursList.Add( rMergedContour );
			}
		}
		return oMergedContoursList;
	}

	public static List<Contour> SimplifyContours( List<Contour> a_rOuterContours, float a_fAccuracy )
	{
		List<Contour> oSimplifiedContoursList = new List<Contour>( a_rOuterContours.Count );

		foreach( Contour rOuterContour in a_rOuterContours )
		{
			// Simplify the new outer contour
			List<Vector2> oOuterContourVertices = new List<Vector2>( rOuterContour.Vertices );

			List<Vector2> oSimplifiedOuterContourVertices = RamerDouglasPeuker( oOuterContourVertices, 0, oOuterContourVertices.Count - 1, a_fAccuracy );

			if( oSimplifiedOuterContourVertices.Count > 2 )
			{	
				// Create the contour
				Contour oSimplifiedOuterContour = new Contour( rOuterContour.Region );
				oSimplifiedOuterContour.AddLast( oSimplifiedOuterContourVertices );
	
				// Add the contour to the list
				oSimplifiedContoursList.Add( oSimplifiedOuterContour );
			}
		}

		return oSimplifiedContoursList;
	}
	
	public static List<Contour> SubdivideContours( List<Contour> a_rOuterContours, float a_fStep )
	{
		List<Contour> oIteratedContoursList = new List<Contour>( a_rOuterContours.Count );

		foreach( Contour rOuterContour in a_rOuterContours )
		{
			// Simplify the new outer contour
			List<Vector2> oOuterContourVertices = new List<Vector2>( rOuterContour.Vertices );
			
			List<Vector2> oIteratedContourVertices = new List<Vector2>();
			for(int i = 0; i < oOuterContourVertices.Count; ++i)
			{
				Vector2 f2SegmentBegin = oOuterContourVertices[i];
				Vector2 f2SegmentEnd = oOuterContourVertices[(i+1)%oOuterContourVertices.Count];
				
				Vector2 f2SegmentDirection = f2SegmentEnd - f2SegmentBegin;
				float fSegmentLength = f2SegmentDirection.magnitude;
				
				int iSubdivisionCount = Mathf.RoundToInt(fSegmentLength / a_fStep);
				//iSubdivisionCount = 2;
				oIteratedContourVertices.Add(f2SegmentBegin);
				if(iSubdivisionCount > 1)
				{
					f2SegmentDirection /= fSegmentLength;
					float fSubdivisionStep = fSegmentLength/(float)(iSubdivisionCount);
					for(int iSubdivision = 1; iSubdivision < iSubdivisionCount; ++iSubdivision)
					{
						oIteratedContourVertices.Add(f2SegmentBegin + f2SegmentDirection * fSubdivisionStep * iSubdivision);
					}
				}
			}

			if( oIteratedContourVertices.Count > 2 )
			{	
				// Create the contour
				Contour oIteratedContour = new Contour( rOuterContour.Region );
				oIteratedContour.AddLast( oIteratedContourVertices );
	
				// Add the contour to the list
				oIteratedContoursList.Add( oIteratedContour );
			}
		}

		return oIteratedContoursList;
	}

	// The Douglas Peucker algorithm is an algorithm for reducing the number of points in a curve that is approximated by a series of points.
	// The purpose of the algorithm is, given a curve composed of line segments, to find a similar curve with fewer points.
	// The algorithm defines 'dissimilar' based on the maximum distance between the original curve and the simplified curve.
	// The simplified curve consists of a subset of the points that defined the original curve.
	public static List<Vector2> RamerDouglasPeuker( List<Vector2> a_rContour, int a_iStartingPixelIndex, int a_iEndingPixelIndex, float a_fAccuracy )
	{
		// List of dominant vertices that define the original curve
		List<Vector2> oDominantContour = new List<Vector2>( );

		// Create a line from the first vertex to the last index
		Vector2 f2StartLineCoords = a_rContour[ a_iStartingPixelIndex ];
		Vector2 f2EndLineCoords   = a_rContour[ a_iEndingPixelIndex ];

		float fDistanceMax = 0.0f;
		int iDominantPixelIndex = -1;

		// Looking for a dominant point which is further than the threshold distance (epsilon)
		for( int iIndex = a_iStartingPixelIndex + 1; iIndex < a_iEndingPixelIndex; ++iIndex )
		{
			Vector2 f2ContourPointCoords = a_rContour[ iIndex ];

			float fDistance = HandleUtility.DistancePointToLine( f2ContourPointCoords, f2StartLineCoords, f2EndLineCoords );

			// New max distance to line
			if( fDistance > fDistanceMax )
			{
				fDistanceMax = fDistance;
				iDominantPixelIndex = iIndex;
			}
		}

		// Dominant point found?
		if( fDistanceMax > a_fAccuracy )
		{
			// Break the line in two at the dominant vertex and apply the algorithm recursively to these 2 segments.
			List<Vector2> rDominantContourLeft  = RamerDouglasPeuker( a_rContour, a_iStartingPixelIndex, iDominantPixelIndex, a_fAccuracy );
			List<Vector2> rDominantContourRight = RamerDouglasPeuker( a_rContour, iDominantPixelIndex, a_iEndingPixelIndex, a_fAccuracy );

			// Add the results
			oDominantContour.AddRange( rDominantContourLeft );
			oDominantContour.RemoveAt( oDominantContour.Count - 1 ); // Avoid duplication of end/start shared bound ( [1..iDominantIndex] U [iDominantIndex..End] )
			oDominantContour.AddRange( rDominantContourRight );
		}
		else
		{
			// No dominant point found -> only the two vertices of the line are really needed
			// to define this part of the curve.
			oDominantContour.Add( f2StartLineCoords );
			oDominantContour.Add( f2EndLineCoords );
		}

		return oDominantContour;
	}
}
#endif