using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UpdateSkinningByQuality : MonoBehaviour
{	
	public QualityLevel.EQuality minimumQuality = QualityLevel.EQuality.Highest;
	
	private Uni2DSprite m_rSprite;
	
	private void Start()
	{
		m_rSprite = GetComponent<Uni2DSprite>();
		if((int)QualityLevel.Instance.Quality < (int)minimumQuality)
		{
			m_rSprite.RenderSkinMode = Uni2DSprite.ERenderSkinMode.ManualUpdateCPU;
		}
		else
		{
			m_rSprite.RenderSkinMode = Uni2DSprite.ERenderSkinMode.GPU;
		}
	}
}
