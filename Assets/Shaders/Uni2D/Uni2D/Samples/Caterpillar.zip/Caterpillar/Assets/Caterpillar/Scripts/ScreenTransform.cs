using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[ExecuteInEditMode()]
[AddComponentMenu("Cosmophony/HUD/ScreenTransform")]
public class ScreenTransform : MonoBehaviour 
{
	public Camera cameraOverride;
	
	public Vector2 viewportAnchor;
	
	public Vector2 viewportOffset;
	
	private Vector2 m_f2ViewportOrigin = new Vector2(0.5f, 0.5f);
	
	public Camera Camera
	{
		get
		{
			if(cameraOverride != null)
			{
				return cameraOverride;
			}
			else
			{
				return Camera.main;
			}
		}
	}
	
	public void SaveCurrentViewportPosition()
	{
		viewportOffset = (Vector2)Camera.WorldToViewportPoint(transform.position) - viewportAnchor - m_f2ViewportOrigin;
	}
	
	public void ApplySavedViewportPosition()
	{
		UpdateAdaptation();
	}
	
	private void Awake()
	{
		if(Application.isPlaying)
		{
			RatioManager.onResolutionChanged += OnResolutionChanged;	
			UpdateAdaptation();
		}
	}
	
	private void OnDestroy()
	{
		RatioManager.onResolutionChanged -= OnResolutionChanged;
	}
	
	private void OnResolutionChanged()
	{
		UpdateAdaptation();
	}
	
	private void UpdateAdaptation()
	{	
		Vector3 f3ViewportPosition = viewportAnchor + viewportOffset + m_f2ViewportOrigin;
		f3ViewportPosition.z = Camera.WorldToViewportPoint(transform.position).z;
		transform.position = Camera.ViewportToWorldPoint(f3ViewportPosition);
	}
}
