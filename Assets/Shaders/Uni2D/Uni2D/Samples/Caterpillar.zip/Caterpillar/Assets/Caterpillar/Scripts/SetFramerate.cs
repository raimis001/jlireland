using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SetFramerate : MonoBehaviour
{
	public int targetFramerate_Good = 30;
	public int targetFramerate_Highest = 60;
	
	public int TargetFramerate
	{
		get
		{
			switch(QualityLevel.Instance.Quality)
			{
				case QualityLevel.EQuality.Good:
				{
					return targetFramerate_Good;
				}
					
				case QualityLevel.EQuality.Highest:
				default:
				{
					return targetFramerate_Highest;
				}
			}
		}
	}
	
	private void Awake()
	{
		Application.targetFrameRate = TargetFramerate;
	}
}
