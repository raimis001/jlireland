﻿using UnityEngine;
using System.Collections;

public class PollenCounter : MonoBehaviour
{
	public TextMesh collectTarget;
	
	public Animator collectAnimator;
	
	private int m_iValue;
	
	private bool m_bDirty;
	
	public void Add(int a_iValueToAdd)
	{
		m_iValue += a_iValueToAdd;
		m_bDirty = true;
		
		if(a_iValueToAdd > 0)
		{
			collectAnimator.speed = 1.0f;
			collectAnimator.Play("collect", 0, 0.0f);
		}
		else if(a_iValueToAdd < 0)
		{
			if(m_iValue < 0)
			{
				m_iValue = 0;
			} 
			
			collectAnimator.speed = 1.0f;
			collectAnimator.Play("lose", 0, 0.0f);
		}
	}
	
	private void Awake()
	{
		UpdateTextMesh();
		collectAnimator.speed = 0.0f;
	}
	
	private void LateUpdate()
	{
		if(m_bDirty)
		{
			UpdateTextMesh();
			m_bDirty = false;
		}
	}
	
	private void UpdateTextMesh()
	{
		collectTarget.text = m_iValue.ToString();
	}
}