using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Caterpillar_Movement : MonoBehaviour
{	
	public Caterpillar caterpillar;
	
	public Caterpillar_GravityCenter gravityCenter;
	
	public float smoothTime = 0.5f;
	
	public float velocityMin = 0.5f;
	public float velocityMax = 2.0f;
	
	public float volumeMin = 0.0f;
	public float volumeMax = 1.0f;
	
	public float pitchMin = 0.0f;
	public float pitchMax = 1.0f;
	
	public AudioClip movementOnBranch;
	
	private AudioSource m_oAudioSource;
	
	private float m_fPercent = 0.0f;
	
	private float m_fPercentVelocity = 0.0f;
	
	private void Awake()
	{
		m_oAudioSource = gameObject.AddComponent<AudioSource>();
		m_oAudioSource.clip = movementOnBranch;
		m_oAudioSource.loop = true;
		SetVelocity(0.0f);
	}
	
	private void Update()
	{
		float fVelocity = 0.0f;
		if(caterpillar.IsGrounded)
		{
			fVelocity = Mathf.Abs(gravityCenter.Velocity.x);
		}
		SetVelocity(fVelocity);
	}
	
	private void SetVelocity(float a_fVelocity)
	{
		float fPercentTarget = Mathf.Clamp01((a_fVelocity - velocityMin)/(velocityMax - velocityMin));
		
		if(m_fPercent != fPercentTarget)
		{
			m_fPercent = Mathf.SmoothDamp(m_fPercent, fPercentTarget, ref m_fPercentVelocity, smoothTime);
		}
		
		float fPitch = Mathf.Lerp(pitchMin, pitchMax, m_fPercent);
		m_oAudioSource.pitch = fPitch;
		
		float fVolume = Mathf.Lerp(volumeMin, volumeMax, m_fPercent);
		m_oAudioSource.volume = fVolume * SoundManager.Instance.MasterVolume;
		
		if(m_fPercent <= 0.0f)
		{
			m_oAudioSource.enabled = false;
		}
		else
		{
			m_oAudioSource.enabled = true;
		}
	}
}
