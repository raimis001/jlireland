using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GamePlayActivation : MonoBehaviour
{
	public List<GameObject> activateOnGamePlay;
	
	private void Awake()
	{
		GameSequence.Instance.onStateChange += OnStateChange;
		OnStateChange();
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
	}
	
	private void OnStateChange()
	{
		if(GameSequence.Instance.State == GameSequence.EState.PlayGame)
		{
			Activate(true);
		}
		else
		{
			Activate(false);
		}
	}
	
	private void Activate(bool a_bActivate)
	{
		foreach(GameObject rGameObject in activateOnGamePlay)
		{
			rGameObject.SetActive(a_bActivate);
		}
	}
}
