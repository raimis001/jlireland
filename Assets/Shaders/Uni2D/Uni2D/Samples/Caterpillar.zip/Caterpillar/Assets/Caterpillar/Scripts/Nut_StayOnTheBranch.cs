﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class Nut_StayOnTheBranch : MonoBehaviour
{
	public Action onHitGround;
	
	public float top = 100.0f;
	
	public float penetrationTolerance = 0.01f;
	
	public float groundedTolerance = 0.0f;
	
	private bool m_bGrounded;
	
	public bool IsGrounded
	{
		get
		{
			return m_bGrounded;	
		}
	}
	
	private void FixedUpdate()
	{	
		bool bWasGrounded = m_bGrounded;
		m_bGrounded = false;
		
		SphereCollider rSphereCollider = collider as SphereCollider;
		if(rSphereCollider != null)
		{
			Vector2 f2Bottom = (Vector2)transform.TransformPoint((Vector2)rSphereCollider.center) - Vector2.up * rSphereCollider.radius * transform.lossyScale.y;
		
			Vector2 f2Top;
			f2Top.x = f2Bottom.x;
			f2Top.y = top;
			
			RaycastHit oHit;
			if(Physics.Raycast(f2Top, -Vector2.up, out oHit, float.PositiveInfinity, 1 << LayerMask.NameToLayer("branch")))
			{	
				float fPenetration = oHit.point.y - f2Bottom.y;
				if(oHit.point.y - f2Bottom.y >= penetrationTolerance)
				{
					Vector2 f2BottomOffset = f2Bottom - (Vector2)transform.position;
					Vector2 f2NextPosition = (Vector2)oHit.point - f2BottomOffset;
					
					rigidbody.position = f2NextPosition;
					transform.position = f2NextPosition;
				}
				
				if(-fPenetration <= groundedTolerance)
				{
					if(bWasGrounded == false)
					{
						if(onHitGround != null)
						{
							onHitGround();
						}
					}
					m_bGrounded = true;
				}
			}
		}
	}
}
