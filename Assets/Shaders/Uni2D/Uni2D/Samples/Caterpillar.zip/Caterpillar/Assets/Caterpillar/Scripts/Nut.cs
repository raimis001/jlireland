using UnityEngine;
using System.Collections;

public class Nut : MonoBehaviour
{
	public System.Action<Nut> onNutEnd;
	
	public float killZ = -100.0f;
	public float jumpOnTopAngleTreshold = 75.0f;
	
	public int pollenCollectCount = 3;
	public float collectPollenVelocity = 2.0f;
	
	public int pollenLoseCount = 3;
	public float losePollenVelocity = 2.0f;
	
	public Collider2D nutCollider;
	public Nut_StayOnTheBranch nutStayOnTheBranch;
	public Transform nutModel;
	
	private bool m_bKilled;
	
	public void End()
	{
		transform.parent = null;
		//collider.enabled = false;
	}
	
	private void Awake()
	{
		nutStayOnTheBranch.onHitGround += OnHitGround;
	}
	
	private void OnDestroy()
	{
		if(nutStayOnTheBranch != null)
		{
			nutStayOnTheBranch.onHitGround += OnHitGround;
		}
	}
	
	private void LateUpdate()
	{
		if(transform.position.y <= killZ)
		{
			NotifyNutEnd();
			Destroy(gameObject);
		}
	}
	
	private void OnCollisionEnter2D(Collision2D a_oCollision)
	{
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		if(m_bKilled)
		{	
			return;
		}
		
		if((a_oCollision.collider.gameObject.layer == LayerMask.NameToLayer("branch") && nutStayOnTheBranch.IsGrounded) == false)
		{
			OnHitSomething();
		}
		
		if(a_oCollision.collider.gameObject.layer == LayerMask.NameToLayer("caterpillar"))
		{
			m_bKilled = true;
			
			bool bJumpedOnTop = false;
			
			Vector2 f2ContactNormal = a_oCollision.contacts[0].normal;
			float fJumpOnAngle = Vector2.Angle(-Vector2.up, f2ContactNormal);
			if(Mathf.Abs(fJumpOnAngle) <= jumpOnTopAngleTreshold)
			{
				bJumpedOnTop = true;
			}
			
			if(bJumpedOnTop)
			{
				OnDestroyByJumpOnTop();
				Destroy(gameObject);
				a_oCollision.collider.GetComponent<Caterpillar_BodyPart>().JumpOnTopOfNut();
			}
			else
			{
				nutCollider.enabled = false;
				nutStayOnTheBranch.enabled = false;
				OnNutHitPlayer();
			}
			
			NotifyNutEnd();
		}
	}
	
	private void OnHitGround()
	{
		OnHitSomething();
	}
	
	private void OnHitSomething()
	{
		SoundPlayer_Nut.Instance.PlayFall();
	}
	
	private void NotifyNutEnd()
	{
		if(onNutEnd != null)
		{
			onNutEnd(this);
		}
	}
	
	private void OnDestroyByJumpOnTop()
	{
		CameraShakes.Instance.jumpOfTopOfNutShake.StartShake();
		CollectFx();
		for(int i = 0; i < pollenCollectCount; ++i)
		{
			float fDirectionAngle = Random.Range(-Mathf.PI, Mathf.PI); 
			Vector2 f2Direction = new Vector2(Mathf.Cos(fDirectionAngle), Mathf.Sin(fDirectionAngle));
			//Debug.Log(f2Direction);
			PollenCollectorManager.Instance.Collect(transform.position, f2Direction * collectPollenVelocity, 1);
		}
		SoundPlayer_Caterpillar.Instance.PlayChestNut();
		SoundPlayer_Pollen_Collect.Instance.PlayPollenStartCollectSound();
		SoundPlayer_Nut.Instance.PlayOpen();
	}
	
	private void OnNutHitPlayer()
	{
		CameraShakes.Instance.hitByNutShake.StartShake();
		for(int i = 0; i < pollenLoseCount; ++i)
		{
			float fDirectionAngle = Random.Range(-Mathf.PI, Mathf.PI); 
			Vector2 f2Direction = new Vector2(Mathf.Cos(fDirectionAngle), Mathf.Sin(fDirectionAngle));
			//Debug.Log(f2Direction);
			PollenCollectorManager.Instance.Lose(transform.position, f2Direction * losePollenVelocity, 1);
		}
		SoundPlayer_Caterpillar.Instance.PlayHurt();
	}
	
	private void CollectFx()
	{
		Nut_CollectFx oNutCollectFx = Instantiate(ItemFactory.Instance.nutCollectFxPrefab) as Nut_CollectFx;

		oNutCollectFx.transform.position = transform.position;
		
		oNutCollectFx.nutModel.localRotation = nutModel.localRotation;
	}
}
