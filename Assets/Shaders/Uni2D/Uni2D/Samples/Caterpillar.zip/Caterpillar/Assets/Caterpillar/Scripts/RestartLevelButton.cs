using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RestartLevelButton : MonoBehaviour
{	
	public Button button;
	
	private void Awake()
	{
		button.onButtonClick += OnButtonClick;
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonClick -= OnButtonClick;
		}
	}
	
	private void OnButtonClick()
	{
		LoadingManager.LoadLevel(Application.loadedLevel);
	}
}