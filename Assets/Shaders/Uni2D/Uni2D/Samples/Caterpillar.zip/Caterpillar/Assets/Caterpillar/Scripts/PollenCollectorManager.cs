﻿using UnityEngine;
using System.Collections;

public class PollenCollectorManager : MonoBehaviour
{
	public PollenCounter pollenCounter;
	
	public Transform collectTarget;
	
	public float multipleCollectDelay = 0.1f;
	
	public float collectVelocityScale = 1.0f;
	
	public float collectDuration = 0.75f;
	
	public Transform loseStartTarget;
	
	public Transform loseEndTarget;
	
	public float multipleLoseDelay = 0.1f;
	
	public float loseVelocityScale = 1.0f;
	
	public float loseDuration = 0.75f;
	
	private static PollenCollectorManager ms_oInstance;
	
	public static PollenCollectorManager Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void Collect(Vector2 a_f2Position, Vector2 a_f2CollectStartVelocity, int a_iPollenCount)
	{		
		PollenCollect oPollenCollect = gameObject.AddComponent<PollenCollect>();
		oPollenCollect.collectPosition = a_f2Position;
		oPollenCollect.collectStartVelocity = a_f2CollectStartVelocity * collectVelocityScale;
		oPollenCollect.pollenCollectRate = multipleCollectDelay;
		oPollenCollect.numberOfPollenToCollect = a_iPollenCount;
		oPollenCollect.pollenCounter = pollenCounter;
		oPollenCollect.collectTarget = collectTarget;
		oPollenCollect.collectDuration = collectDuration;
	}
	
	public void Lose(Vector2 a_f2Position, Vector2 a_f2LoseStartVelocity, int a_iPollenCount)
	{
		PollenLose oPollenLose = gameObject.AddComponent<PollenLose>();
		oPollenLose.losePosition = a_f2Position;
		oPollenLose.loseStartVelocity = a_f2LoseStartVelocity * loseVelocityScale;
		oPollenLose.pollenLoseRate = multipleLoseDelay;
		oPollenLose.numberOfPollenToLose = a_iPollenCount;
		oPollenLose.pollenCounter = pollenCounter;
		oPollenLose.loseDuration = loseDuration;
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}