using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Button_SpriteIntensity : MonoBehaviour
{	
	public Button button;
	
	public SpriteRenderer spriteRenderer;
	
	public float buttonDownIntensity = 0.75f;
	
	private void Awake()
	{
		button.onButtonDown += OnButtonDown;
		button.onButtonUp += OnButtonUp;
		
		UpdateSprite();
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonDown -= OnButtonDown;
			button.onButtonUp -= OnButtonUp;
		}
	}
	
	private void OnButtonDown()
	{
		UpdateSprite();
	}
	
	private void OnButtonUp()
	{
		UpdateSprite();
	}
	
	private void UpdateSprite()
	{
		if(button == null)
		{
			return;
		}
		
		SetSpriteDown(button.Pressed);
	}
	
	private void SetSpriteDown(bool a_bDown)
	{
		if(spriteRenderer == null)
		{
			return;
		}
		
		if(a_bDown)
		{
			spriteRenderer.color = new Color(buttonDownIntensity, buttonDownIntensity, buttonDownIntensity);
		}
		else
		{
			spriteRenderer.color = Color.white;
		}
	}
}