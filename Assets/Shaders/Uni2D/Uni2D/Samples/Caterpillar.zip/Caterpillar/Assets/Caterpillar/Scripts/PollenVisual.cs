﻿using UnityEngine;
using System.Collections;

public class PollenVisual : MonoBehaviour
{
	public Uni2DSprite sprite;
	
	public Color Color
	{
		get
		{
			return sprite.VertexColor;
		}
		
		set
		{
			sprite.VertexColor = value;
		}
	}
}
