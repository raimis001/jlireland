using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraConstraintToRectangleZone : MonoBehaviour
{
	public Camera cameraComponent;
	public Vector2 rectangleZoneSize;
	
	private Vector2 Extent
	{
		get
		{
			return rectangleZoneSize * 0.5f;
		}
	}
	
	private void OnDrawGizmos()
	{
		Vector2 f2Extent = Extent;
		Vector3 f3TopLeft = new Vector3(-f2Extent.x, f2Extent.y, 0);
		Vector3 f3TopRight = new Vector3(f2Extent.x, f2Extent.y, 0);
		Vector3 f3BottomRight = new Vector3(f2Extent.x, -f2Extent.y, 0);
		Vector3 f3BottomLeft = new Vector3(-f2Extent.x, -f2Extent.y, 0);
		
		Gizmos.color = Color.green;
		
		Gizmos.DrawLine(f3TopLeft, f3TopRight);
		Gizmos.DrawLine(f3TopRight, f3BottomRight);
		Gizmos.DrawLine(f3BottomRight, f3BottomLeft);
		Gizmos.DrawLine(f3BottomLeft, f3TopLeft);
	}
	
	private void FixedUpdate()
	{
		Vector2 f2Extent = Extent;
		
		Vector3 f3Position = cameraComponent.transform.position;
		Vector3 f3ConstrainedPosition = cameraComponent.transform.position;
		
		Vector2 f2ScreenExtent;
		f2ScreenExtent.y = cameraComponent.orthographicSize;
		f2ScreenExtent.x = f2ScreenExtent.y * (float)Screen.width/(float)Screen.height;
		
		if((f3ConstrainedPosition.x - f2ScreenExtent.x) < -f2Extent.x)
		{
			f3ConstrainedPosition.x = -f2Extent.x + f2ScreenExtent.x;
		}
		else if((f3ConstrainedPosition.x + f2ScreenExtent.x) > f2Extent.x)
		{
			f3ConstrainedPosition.x = f2Extent.x - f2ScreenExtent.x;
		}
		
		if((f3ConstrainedPosition.y - f2ScreenExtent.y) < -f2Extent.y)
		{
			f3ConstrainedPosition.y = -f2Extent.y + f2ScreenExtent.y;
		}
		else if((f3ConstrainedPosition.y + f2ScreenExtent.y) > f2Extent.y)
		{
			f3ConstrainedPosition.y = f2Extent.y - f2ScreenExtent.y;
		}
		
		transform.position += f3ConstrainedPosition - f3Position;
	}
}
