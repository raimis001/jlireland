using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ParentConstraint : MonoBehaviour
{
	public enum EUpdateMode
	{
		Update,
		LateUpdate,
		FixedUpdate
	}
	
	public Transform parentTransform;
	
	public EUpdateMode updateMode = EUpdateMode.LateUpdate;
	
	private void Update()
	{
		if(updateMode == EUpdateMode.Update)
		{
			UpdateConstraint();
		}
	}
	
	private void LateUpdate()
	{
		if(updateMode == EUpdateMode.LateUpdate)
		{
			UpdateConstraint();
		}
	}
	
	private void FixedUpdate()
	{
		if(updateMode == EUpdateMode.FixedUpdate)
		{
			UpdateConstraint();
		}
	}
	
	private void UpdateConstraint()
	{
		transform.rotation = parentTransform.rotation;
		transform.position = parentTransform.position;
	}
}
