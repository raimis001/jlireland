using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Branch_Pick : MonoBehaviour
{	
	[System.Serializable]
	public class PickSound
	{
		public SoundPlayer_ShuffledSequence soundPlayer;
		public float movementLengthMin = 1.0f;
		
		public void Play()
		{
			//SoundManager.Instance.PlaySound(sound, volume);
			soundPlayer.PlaySound();
		}
	}
	
	public Branch branch;
	
	public List<PickSound> pickSounds;
	
	private bool m_bPlayedPickSoundThisFrame;
	
	private void Awake()
	{
		Branch.BoneTarget.onBoneTargetPick += OnBoneTargetPick;
	}
	
	private void OnDestroy()
	{
		Branch.BoneTarget.onBoneTargetPick -= OnBoneTargetPick;
	}
	
	private void FixedUpdate()
	{
		m_bPlayedPickSoundThisFrame = false;
	}
	
	private void OnBoneTargetPick(Branch.BoneTarget a_rBoneTarget)
	{
		PlayPickBoneSound(a_rBoneTarget.TargetDistance);
	}
	
	private void PlayPickBoneSound(float a_fMovementLength)
	{
		if(m_bPlayedPickSoundThisFrame)
		{
			return;
		}
		m_bPlayedPickSoundThisFrame = true;
		
		//Debug.Log(a_fMovementLength);
		for(int i = pickSounds.Count - 1; i >= 0; --i)
		{
			PickSound rPickSound = pickSounds[i]; 
			if(a_fMovementLength >= rPickSound.movementLengthMin)
			{
				rPickSound.Play();
				break;
			}
		}
	}
}
