using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ActivateByQuality : MonoBehaviour
{	
	public QualityLevel.EQuality quality;
	
	public List<GameObject> gameObjectsToActivate;
	
	private void Awake()
	{
		Activate(QualityLevel.Instance.Quality == quality);
	}
	
	private void Activate(bool a_bActivate)
	{
		foreach(GameObject rGameObject in gameObjectsToActivate)
		{
			rGameObject.SetActive(a_bActivate);
		}
	}
}
