using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DelayActivation : MonoBehaviour
{
	public int delayFrameCount = 2;
	
	public GameObject gameObjectToActivate;
	
	private int m_iFrameCount = 0;
	
	private bool m_bStarted = false;
	
	private void Awake()
	{	
		gameObjectToActivate.SetActive(false);
	}
	
	private void Update()
	{
		if(m_bStarted == false)
		{
			++m_iFrameCount;
			if(m_iFrameCount >= delayFrameCount)
			{
				gameObjectToActivate.SetActive(true);
			}
		}
	}
}
