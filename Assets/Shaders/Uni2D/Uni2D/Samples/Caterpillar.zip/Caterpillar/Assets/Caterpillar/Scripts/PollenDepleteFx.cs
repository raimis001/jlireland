﻿using UnityEngine;
using System.Collections;

public class PollenDepleteFx : MonoBehaviour
{
	public ParticleSystem pollenDepleteParticleSystem;
	
	private void LateUpdate()
	{
		if(pollenDepleteParticleSystem.IsAlive() == false)
		{
			Destroy(gameObject);
		}
	}
}
