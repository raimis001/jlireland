using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_ShuffledSequence : MonoBehaviour
{	
	public AudioClip[] sounds;
	
	public float volume;
	
	private int m_iCurrentIndex;
	
	private List<int> m_oShuffledIndices = new List<int>();
	
	public void PlaySound()
	{
		if(sounds.Length > 0)
		{
			++m_iCurrentIndex;
			if(m_iCurrentIndex >= sounds.Length)
			{
				m_iCurrentIndex = 0;
				Shuffle();
			}
			SoundManager.Instance.PlaySound(sounds[GetShuffledIndex(m_iCurrentIndex)], volume);
		}
	}
	
	private void Awake()
	{
		Shuffle();
	}
	
	private void Shuffle()
	{
		m_oShuffledIndices.Clear();
		
		List<int> oSortedIndices = new List<int>();
		for(int i = 0; i < sounds.Length; ++i)
		{
			oSortedIndices.Add(i);
		}
		
		while(oSortedIndices.Count > 0)
		{
			int iRemainingSortedIndicesSelectedIndex = Random.Range(0, oSortedIndices.Count);
			
			m_oShuffledIndices.Add(oSortedIndices[iRemainingSortedIndicesSelectedIndex]);
			
			oSortedIndices.RemoveAt(iRemainingSortedIndicesSelectedIndex);
		}
	}
	
	private int GetShuffledIndex(int a_iIndex)
	{
		return m_oShuffledIndices[a_iIndex];
	}
}
