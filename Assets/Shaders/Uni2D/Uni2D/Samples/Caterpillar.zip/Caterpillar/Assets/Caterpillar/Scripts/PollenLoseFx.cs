﻿using UnityEngine;
using System.Collections;

public class PollenLoseFx : MonoBehaviour
{
	public float loseDuration = 0.5f;
	
	public Animator loseAnimator;
	
	private Vector3 m_f3LoseVelocity;
	
	private float loseTimeRemaining;
	
	public void StartLose(Vector2 a_f2CollectStartVelocity)
	{
		m_f3LoseVelocity = a_f2CollectStartVelocity;
		loseTimeRemaining = loseDuration;
		
		loseAnimator.speed = 1.0f/loseDuration;
	}
	
	private void LateUpdate()
	{
		UpdateLose();
	}
	
	private void StopLose()
	{
		Destroy(gameObject);
	}
	
	private void UpdateLose()
	{
		loseTimeRemaining -= Time.deltaTime;
		if(loseTimeRemaining > 0.0f)
		{
			transform.localPosition += m_f3LoseVelocity;
		}
		else
		{
			StopLose();
		}
	}
}
