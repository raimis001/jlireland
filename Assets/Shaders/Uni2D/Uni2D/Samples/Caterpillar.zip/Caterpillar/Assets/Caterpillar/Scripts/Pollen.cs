using UnityEngine;
using System.Collections;

public class Pollen : MonoBehaviour
{
	public static System.Action<Pollen> onPollenPickedUpGlobal;
	
	public System.Action<Pollen> onPollenPickedUp;
	
	public PollenVisualSpawner pollenVisualSpawner;
	
	public Color doubleGainColor = Color.red;
	
	private Color m_oNormalGainColor;
	
	private bool m_bPickedUp = false;
	
	private int m_iGain = 1;
	
	public void DoubleGain()
	{
		pollenVisualSpawner.PollenVisual.Color = doubleGainColor;
		m_iGain = 2;
	}
	
	public void CancelDoubleGain()
	{
		pollenVisualSpawner.PollenVisual.Color = m_oNormalGainColor;
		m_iGain = 1;
	}
	
	private void Awake()
	{
		m_oNormalGainColor = pollenVisualSpawner.PollenVisual.Color;
	}
	
	private void OnTriggerEnter2D(Collider2D a_oCollider2D)
	{
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		//Debug.Log("Collision : " + a_oCollider);
		if(m_bPickedUp == false)
		{
			OnPollenPickedUp(a_oCollider2D.attachedRigidbody.velocity);
			Destroy(gameObject);
		}
	}
	
	private void OnPollenPickedUp(Vector2 a_f2PickUpVelocity)
	{
		PollenCollectorManager.Instance.Collect(transform.position, a_f2PickUpVelocity, m_iGain);
		SoundPlayer_Pollen_Collect.Instance.PlayPollenStartCollectSound();
		m_bPickedUp = true;
		if(onPollenPickedUp != null)
		{
			onPollenPickedUp(this);
		}
		if(onPollenPickedUpGlobal != null)
		{
			onPollenPickedUpGlobal(this);
		}
	}
}
