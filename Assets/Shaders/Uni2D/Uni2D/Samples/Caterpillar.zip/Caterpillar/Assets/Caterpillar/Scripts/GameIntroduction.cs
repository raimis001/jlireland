using UnityEngine;
using System.Collections;

public class GameIntroduction : MonoBehaviour
{
	public float introductionDuration = 2.0f;
	
	private void Start()
	{
		Invoke("StartGame", introductionDuration);
	}
	
	private void StartGame()
	{
		GameSequence.Instance.PlayGame();
	}
}
