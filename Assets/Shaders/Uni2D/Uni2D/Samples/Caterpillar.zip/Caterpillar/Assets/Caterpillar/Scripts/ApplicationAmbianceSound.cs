using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ApplicationAmbianceSound : MonoBehaviour
{
	public AudioClip ambianceSound;
	
	public float volume = 0.3f;
	
	public float smoothTime = 0.5f; 
	
	private float m_fSmoothVelocity;
	
	private AudioSource m_rAudioSource;
	
	private static ApplicationAmbianceSound ms_oInstance;
	
	public void SetVolume(float a_fVolume)
	{
		m_rAudioSource.volume = a_fVolume;
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
			DontDestroyOnLoad(ms_oInstance);
		}
		else
		{
			Destroy(gameObject);
			return;
		}
		
		m_rAudioSource = gameObject.AddComponent<AudioSource>();
		m_rAudioSource.clip = ambianceSound;
		m_rAudioSource.loop = true;
		
		SetVolume(0.0f);
		
		m_rAudioSource.Play();
	}
	
	private void Update()
	{
		float fVolume = GetVolume();
		
		fVolume = Mathf.SmoothDamp(fVolume, volume, ref m_fSmoothVelocity, smoothTime);
		
		SetVolume(fVolume);
	}
	
	private float GetVolume()
	{
		return m_rAudioSource.volume;
	}
}
