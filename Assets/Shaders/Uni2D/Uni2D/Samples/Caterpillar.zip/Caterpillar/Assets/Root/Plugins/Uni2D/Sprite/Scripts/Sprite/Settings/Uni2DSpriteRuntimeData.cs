using UnityEngine;
using System.Collections;

/*
 * Uni2DSpriteRuntimeData
 * 
 * Sprite data created and used at runtime.
 * 
 */
public class Uni2DSpriteRuntimeData
{
	public Material animationMaterial = null;	
}
