using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Upsight_MoreGamesButton : MonoBehaviour
{
	public string placementName = "moregames"; 
	
	#if UNITY_ANDROID || UNITY_IPHONE
	private Button m_rButton;
	
	private void Awake()
	{
		m_rButton = GetComponent<Button>();
		
		m_rButton.onButtonClick += OnButtonClick;
	}
	
	private void Start()
	{
		Upsight.preloadContentRequest(placementName);
	}
	
	private void OnDestroy()
	{
		if(m_rButton != null)
		{
			m_rButton.onButtonClick += OnButtonClick;
		}
	}
	
	private void OnButtonClick()
	{
		Debug.Log("sendContentRequest : " + placementName);
		Upsight.sendContentRequest(placementName, true);
	}
	#else
	private void Awake()
	{
		Destroy(gameObject);
	}
	#endif
}
