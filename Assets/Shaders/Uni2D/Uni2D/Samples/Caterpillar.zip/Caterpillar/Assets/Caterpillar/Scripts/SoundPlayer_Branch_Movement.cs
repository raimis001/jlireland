using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Branch_Movement : MonoBehaviour
{	
	public Branch branch;
	
	public float velocity;
	
	public float percent1;
	public float percent2;
	
	public float smoothTime = 0.5f;
	
	public float maxPercent1 = 0.2f;
	
	public float velocityMin = 0.0f;
	public float velocityMax = 1.0f;
	
	public float volume1 = 1.0f;
	public float volume2 = 1.0f;
	
	public AudioClip branchMovement1;
	public AudioClip branchMovement2;
	
	private AudioSource m_oAudioSource1;
	private AudioSource m_oAudioSource2;
	
	private float m_fPercent = 0.0f;
	
	private float m_fPercentVelocity = 0.0f;
	
	private void Awake()
	{
		m_oAudioSource1 = gameObject.AddComponent<AudioSource>();
		m_oAudioSource1.clip = branchMovement1;
		m_oAudioSource1.loop = true;
		
		m_oAudioSource2 = gameObject.AddComponent<AudioSource>();
		m_oAudioSource2.clip = branchMovement2;
		m_oAudioSource2.loop = true;
		
		SetVelocity(0.0f);
	}
	
	private void Update()
	{
		SetVelocity(Mathf.Abs(branch.Velocity));
	}
	
	private void SetVelocity(float a_fVelocity)
	{
		velocity = a_fVelocity;
		float fPercentTarget = Mathf.Clamp01((a_fVelocity - velocityMin)/(velocityMax - velocityMin));
		
		if(m_fPercent != fPercentTarget)
		{
			m_fPercent = Mathf.SmoothDamp(m_fPercent, fPercentTarget, ref m_fPercentVelocity, smoothTime);
		}
		
		float fPercent1 = 0.0f;
		float fPercent2 = 0.0f;
		
		if(m_fPercent <= maxPercent1)
		{
			fPercent1 = m_fPercent/maxPercent1;
		}
		else
		{
			fPercent2 = (m_fPercent - maxPercent1)/(1.0f - maxPercent1);
			fPercent1 = 1.0f - fPercent2;
		}
		
		// 1
		float fVolume1 = Mathf.Lerp(0.0f, volume1, fPercent1);
		m_oAudioSource1.volume = fVolume1 * SoundManager.Instance.MasterVolume;
		
		if(fPercent1 <= 0.0f)
		{
			m_oAudioSource1.enabled = false;
		}
		else
		{
			m_oAudioSource1.enabled = true;
		}
		
		percent1 = fPercent1;
		
		// 2
		float fVolume2 = Mathf.Lerp(0.0f, volume2, fPercent2);
		m_oAudioSource2.volume = fVolume2 * SoundManager.Instance.MasterVolume;
		
		if(fPercent2 <= 0.0f)
		{
			m_oAudioSource2.enabled = false;
		}
		else
		{
			m_oAudioSource2.enabled = true;
		}
		
		percent2 = fPercent2;
	}
}
