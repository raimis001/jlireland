using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Caterpillar : MonoBehaviour
{	
	public AudioClip fall;
	public AudioClip hurt;
	public AudioClip chestNut;
	
	public float volume;
	
	public SoundPlayer_ShuffledSequence jump;
	
	private static SoundPlayer_Caterpillar ms_oInstance;
	
	public static SoundPlayer_Caterpillar Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlayFall()
	{
		SoundManager.Instance.PlaySound(fall, volume);
	}
	
	public void PlayHurt()
	{
		SoundManager.Instance.PlaySound(hurt, volume);
	}
	
	public void PlayChestNut()
	{
		SoundManager.Instance.PlaySound(chestNut, volume);
	}
	
	public void PlayJump()
	{
		jump.PlaySound();
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
