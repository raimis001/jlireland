using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode()]
public class SetOrderInLayer : MonoBehaviour 
{	
	public string sortingLayerName;
	public int orderInLayer;
	
	private void Update()
	{
		if(renderer != null)
		{
			renderer.sortingLayerName = sortingLayerName;
			renderer.sortingOrder = orderInLayer;
		}	
	}
}
