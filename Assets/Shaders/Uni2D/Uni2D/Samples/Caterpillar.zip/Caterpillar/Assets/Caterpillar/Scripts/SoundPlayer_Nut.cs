using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Nut : MonoBehaviour
{	
	public AudioClip fall;
	public AudioClip open;
	
	private static SoundPlayer_Nut ms_oInstance;
	
	public static SoundPlayer_Nut Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlayFall()
	{
		SoundManager.Instance.PlaySound(fall);
	}
	
	public void PlayOpen()
	{
		SoundManager.Instance.PlaySound(open);
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
