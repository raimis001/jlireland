using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Pollen_PreSpawnFx : MonoBehaviour
{	
	public AudioClip preSpawnFxSound;
	
	public float volume = 1.0f;
	
	public float smoothTime = 0.5f;
	
	private AudioSource m_oAudioSource;
	
	private float m_fPercent = 0.0f;
	
	private float m_fPercentVelocity = 0.0f;
	
	private int m_iSoundPlayerCount;
	
	private static SoundPlayer_Pollen_PreSpawnFx ms_oInstance;
	
	public static SoundPlayer_Pollen_PreSpawnFx Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void RegisterSoundPlayer()
	{
		++m_iSoundPlayerCount;
	}
	
	public void UnregisterSoundPlayer()
	{
		--m_iSoundPlayerCount;
		if(m_iSoundPlayerCount <= 0)
		{
			m_iSoundPlayerCount = 0;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
		
		m_oAudioSource = gameObject.AddComponent<AudioSource>();
		m_oAudioSource.clip = preSpawnFxSound;
		m_oAudioSource.loop = true;
		
		UpdateSound();
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
	
	private void Update()
	{
		UpdateSound();
	}
	
	private void UpdateSound()
	{
		float fPercentTarget;
		if(m_iSoundPlayerCount > 0)
		{
			fPercentTarget = 1.0f;
		}
		else
		{
			fPercentTarget = 0.0f;
		}
		
		if(m_fPercent != fPercentTarget)
		{
			m_fPercent = Mathf.SmoothDamp(m_fPercent, fPercentTarget, ref m_fPercentVelocity, smoothTime);
		}
		
		float fVolume = m_fPercent * volume;
		m_oAudioSource.volume = fVolume * SoundManager.Instance.MasterVolume;
		
		if(m_fPercent <= 0.0f)
		{
			m_oAudioSource.enabled = false;
		}
		else
		{
			m_oAudioSource.enabled = true;
		}
	}
}
