#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public class AudioPostprocessor2D : AssetPostprocessor 
{
	private void OnPreprocessAudio()
	{
		if(assetPath.Contains("2D"))
		{
			AudioImporter rAudioImporter = assetImporter as AudioImporter;
			rAudioImporter.threeD = false;
		}
	}
}
#endif
