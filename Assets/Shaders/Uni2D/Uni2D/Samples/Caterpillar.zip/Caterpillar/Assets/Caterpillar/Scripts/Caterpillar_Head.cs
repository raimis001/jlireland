﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_Head : MonoBehaviour
{
	public enum EMouthState
	{
		Close,
		Open
	}
	
	public enum EEyeState
	{
		Close,
		Open,
		WideOpen
	}
	
	public Uni2DSprite sprite;
	
	public EMouthState mouth;
	
	public EEyeState eye;
	
	private EMouthState m_eCurrentMouthState;
	
	private EEyeState m_eCurrentEyeState;
	
	private void Start()
	{
		SetHeadStates(mouth, eye);
	}
	
	private void LateUpdate()
	{
		UpdateHeadStates();
	}
	
	private void UpdateHeadStates()
	{
		if(mouth != m_eCurrentMouthState || eye != m_eCurrentEyeState)
		{
			SetHeadStates(mouth, eye);
		}
	}
	
	private void SetHeadStates(EMouthState a_eMouthState, EEyeState a_eEyeState)
	{
		m_eCurrentMouthState = a_eMouthState;
		m_eCurrentEyeState = a_eEyeState;
		
		string oFrameName = "Mouth" + m_eCurrentMouthState + "_" + "Eye" + m_eCurrentEyeState;
		//Debug.Log("Before Apply : " + oFrameName);
		sprite.spriteAnimation.FrameName = oFrameName;
		//Debug.Log("After Apply : " + sprite.spriteAnimation.FrameName);
	}
}
