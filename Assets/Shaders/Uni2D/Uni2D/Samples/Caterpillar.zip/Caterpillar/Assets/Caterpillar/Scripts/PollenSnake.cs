﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PollenSnake : SubWave
{
	public int pollenCount = 5;
	
	public float startFxDelay = 0.0f;
	
	private PositionRecords m_oPositionRecords;
	
	private bool m_bWaitForSpawn = true;
	private bool m_bSpawnInProgress = false;
	
	private List<Pollen> m_oPollens = new List<Pollen>();
	private HashSet<Pollen> m_oPickedUpPollens = new HashSet<Pollen>();
	
	private PositionRecords.CurveVertex m_rStartSpawnCurveVertex;
	private PositionRecords.CurveVertex m_rLastSpawnCurveVertex;
	
	private PollenPreSpawnFx m_oPreSpawnFx;
	
	private PollenChain m_oPollenChain;
	
	public bool WaitForSpawn
	{
		get
		{
			return m_bWaitForSpawn;
		}
	}
	
	public void PollenChainEnd()
	{
		SubWaveEnd();
	}
	
	public void StartSpawn()
	{
		if(m_bWaitForSpawn)
		{
			m_bWaitForSpawn = false;
			
			m_rStartSpawnCurveVertex = m_oPositionRecords.PreviousCurveVertex;
			m_bSpawnInProgress = true;
			Spawn();
			
			m_oPreSpawnFx.AnchorFx(m_rStartSpawnCurveVertex.position);
		}
	}
	
	protected override void Awake()
	{
		base.Awake();
		
		m_oPositionRecords = gameObject.AddComponent<PositionRecords>();
		m_oPositionRecords.minimumSpaceBetweenPositionRecords = Parameters_PollenChain.Instance.minimumSpaceBetweenPosition;
		m_oPositionRecords.maxPositionRecordsCount = Parameters_PollenChain.Instance.maxSavedPositionCount;
		
		m_oPollenChain = PollenChain.CreatePollenChain(gameObject);
		m_oPreSpawnFx = PollenPreSpawnFx.CreatePollenPreSpawnFX(gameObject);
	}
	
	private void Start()
	{
		m_oPreSpawnFx.StartFx(startFxDelay);
	}
	
	private void LateUpdate()
	{
		if(m_bSpawnInProgress)
		{
			UpdateSpawn();
		}
		
		if(m_oPollens.Count > 0)
		{
			PlacePollensOnCurve(Parameters_PollenChain.Instance.spaceBetweenPollen);
		}
	}
	
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.green;
		Gizmos.DrawWireSphere(transform.position, 1.0f);
	}
	
	private void StopSpawn()
	{
		m_bSpawnInProgress = false;
		m_oPreSpawnFx.StopFx();
	}
	
	private void UpdateSpawn()
	{	
		PositionRecords.CurveVertex rCurrentCurveVertex = m_oPositionRecords.CurrentCurveVertex;
		if(rCurrentCurveVertex.curveAbscisse - m_rLastSpawnCurveVertex.curveAbscisse >= Parameters_PollenChain.Instance.spaceBetweenPollenAtSpawn)
		{
			Spawn();
		}
	}
	
	private void Spawn()
	{
		m_rLastSpawnCurveVertex = m_oPositionRecords.CurrentCurveVertex;
		
		Pollen oPollen = Instantiate(ItemFactory.Instance.pollenPrefab) as Pollen;
		oPollen.transform.parent = transform;
		
		oPollen.transform.position = m_rStartSpawnCurveVertex.position;
		m_oPollens.Add(oPollen);
		
		m_oPollenChain.AddPollen(oPollen);
		
		oPollen.onPollenPickedUp += OnPollenPickedUp;
		
		SoundPlayer_Pollen_Spawn.Instance.PlayPollenSpawnSound();
		
		if(m_oPollens.Count >= pollenCount)
		{
			StopSpawn();
		}
	}
	
	private void PlacePollensOnCurve(float a_fSpaceBetweenPollen)
	{	
		List<PositionRecords.CurveVertex> rVertices = m_oPositionRecords.CurveVertices;
		
		int iCurveVertexCount = rVertices.Count;
		int iPollenCount = m_oPollens.Count;
		
		float fChainLengthSinceSpawn = m_oPositionRecords.CurrentCurveVertex.curveAbscisse - m_rStartSpawnCurveVertex.curveAbscisse;
		float fSpaceMaxBetweenPollen = fChainLengthSinceSpawn / (float)iPollenCount;
		a_fSpaceBetweenPollen = Mathf.Min(fSpaceMaxBetweenPollen, a_fSpaceBetweenPollen);
		
		// First pollen on last vertex 
		Pollen rFirstPollen = m_oPollens[0];
		if(rFirstPollen != null)
		{
			m_oPollens[0].transform.position = rVertices[iCurveVertexCount - 1].position;
		}
		
		float fDistanceToLastAttached = 0.0f;
		for(int iVertexIndex = iCurveVertexCount - 2, iPollenIndex = 1; iVertexIndex >= 0 && iPollenIndex < iPollenCount; --iVertexIndex)
		{
			PositionRecords.CurveVertex rVertex = rVertices[iVertexIndex];
			
			PositionRecords.CurveVertex rLastVertex = rVertices[iVertexIndex + 1];
			
			float fNextSegmentLength = (rVertex.position - rLastVertex.position).magnitude;
			
			float fNextDistanceToLastAttached = fDistanceToLastAttached + fNextSegmentLength;
			if(fNextDistanceToLastAttached < a_fSpaceBetweenPollen)
			{
				fDistanceToLastAttached = fNextDistanceToLastAttached;
				continue;
			}
			
			float fSegmentPercent =  (a_fSpaceBetweenPollen - fDistanceToLastAttached) / fNextSegmentLength;
			Vector2 f2PollenPosition = Vector2.Lerp(rLastVertex.position, rVertex.position, fSegmentPercent);
			
			Pollen rPollen = m_oPollens[iPollenIndex];
			if(rPollen != null)
			{
				rPollen.transform.position = f2PollenPosition;
			}
			fDistanceToLastAttached = fNextSegmentLength * (1.0f - fSegmentPercent);
			
			++iPollenIndex;
		}
	}
	
	private void OnPollenPickedUp(Pollen a_rPollen)
	{	
		if(m_oPickedUpPollens.Contains(a_rPollen) == false)
		{
			m_oPickedUpPollens.Add(a_rPollen);
			if(m_oPickedUpPollens.Count >= m_oPollens.Count)
			{
				PollenChainEnd();
			}
		}
	}
}
