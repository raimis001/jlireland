using UnityEngine;
using System.Collections;
using System;

[AddComponentMenu("Cosmophony/HUD/WidthRatioAdaptator")]
// WidthRatioAdaptator
public class WidthRatioAdaptator : MonoBehaviour
{	
	public bool uniformStretch = false;
	
	public bool orthographic = false;
	
	private Vector3 m_f3InitialLocalScale;
	
	private void Awake()
	{		
		m_f3InitialLocalScale = transform.localScale;
		
		UpdateAdaptation();
		RatioManager.onResolutionChanged += OnResolutionChanged;
	}
	
	private void OnDestroy()
	{
		RatioManager.onResolutionChanged -= OnResolutionChanged;
	}
	
	private void OnResolutionChanged()
	{
		UpdateAdaptation();
	}
	
	private void UpdateAdaptation()
	{
		Vector3 f3LocalScale = m_f3InitialLocalScale;

		RatioManager rRatioManager = RatioManager.Instance;

		float fScale = rRatioManager.RatioIncreaseWidth;
		f3LocalScale.x *= fScale;
		
		if(fScale < 1.0f && uniformStretch)
		{
			f3LocalScale.y *= fScale;
		}
		
		if(orthographic)
		{
			float fHeightIncrease = rRatioManager.CurrentHeightOnWidthRatio;
			if(fHeightIncrease <= 1.0f)
			{
				fHeightIncrease = 1.0f;
			}
			f3LocalScale.x *= fHeightIncrease;
			f3LocalScale.y *= fHeightIncrease;
		}
		
		transform.localScale = f3LocalScale;	
	}
}