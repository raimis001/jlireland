﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PositionRecords : MonoBehaviour
{
	public class CurveVertex
	{
		public Vector2 position;
		public float curveAbscisse;
		
		public CurveVertex(Vector2 a_f2Position, float a_fCurveAbscisse)
		{
			position = a_f2Position;
			curveAbscisse = a_fCurveAbscisse;
		}
	}
	
	public float minimumSpaceBetweenPositionRecords;
	public int maxPositionRecordsCount;
	
	private List<CurveVertex> m_oCurveVertices = new List<CurveVertex>();
	
	public CurveVertex CurrentCurveVertex
	{
		get
		{
			return m_oCurveVertices[m_oCurveVertices.Count - 1];
		}
	}
	
	public CurveVertex PreviousCurveVertex
	{
		get
		{
			return m_oCurveVertices[m_oCurveVertices.Count - 2];
		}
	}
	
	public List<CurveVertex> CurveVertices
	{
		get
		{
			return m_oCurveVertices;
		}
	}
	
	private void Awake()
	{
		Vector2 f2Position = transform.position;
		m_oCurveVertices.Add(new CurveVertex(f2Position, 0.0f));
		m_oCurveVertices.Add(new CurveVertex(f2Position, 0.0f));
	}
	
	private void LateUpdate()
	{
		UpdatePositionRecords();
	}
	
	private void UpdatePositionRecords()
	{	
		Vector2 f2CurrentPosition = transform.position;
		CurveVertex rCurrentCurveVertex = m_oCurveVertices[m_oCurveVertices.Count - 1];
		rCurrentCurveVertex.position = f2CurrentPosition;
		
		CurveVertex rPreviousCurveVertex = m_oCurveVertices[m_oCurveVertices.Count - 2];
		Vector2 f2PreviousPosition = rPreviousCurveVertex.position;
		
		float fDistanceToPreviousPosition = (f2CurrentPosition - f2PreviousPosition).magnitude;
		rCurrentCurveVertex.curveAbscisse = fDistanceToPreviousPosition + rPreviousCurveVertex.curveAbscisse;
		if(fDistanceToPreviousPosition >= minimumSpaceBetweenPositionRecords)
		{
			m_oCurveVertices.Add(new CurveVertex(rCurrentCurveVertex.position, rCurrentCurveVertex.curveAbscisse));
			
			int iRecordInExcessCount = (m_oCurveVertices.Count - 1) - maxPositionRecordsCount;
			if(iRecordInExcessCount > 0)
			{
				m_oCurveVertices.RemoveRange(0, iRecordInExcessCount);
			}
		}
	}
	
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.green;
		for(int i = 0; i < m_oCurveVertices.Count - 1; ++i)
		{
			Gizmos.DrawLine(m_oCurveVertices[i].position, m_oCurveVertices[i+1].position);
		}
	}
}
