﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Nut_StartOrientation : MonoBehaviour
{
	private void Awake()
	{		
		float fAngleX = Random.Range(0.0f, 360.0f);
		float fAngleY = Random.Range(0.0f, 360.0f);
		float fAngleZ = Random.Range(0.0f, 360.0f);
		
		transform.localRotation = Quaternion.Euler(fAngleX, fAngleY, fAngleZ);
	}
}
