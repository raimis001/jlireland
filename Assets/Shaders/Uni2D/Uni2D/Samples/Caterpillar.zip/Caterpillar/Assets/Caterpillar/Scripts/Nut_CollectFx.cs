﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Nut_CollectFx : MonoBehaviour
{
	public List<Rigidbody> chestRigidbodies;
	
	public List<GameObject> seeds;
	
	public float explosionForce = 10.0f;
	
	public float explosionUpwardModifier = 3.0f;
	
	public float seedAngularRotationMax = 360.0f;
	
	public Transform nutModel;
	
	public float duration = 3.0f;
	
	private void Start()
	{
		// Select randomly a seed
		GameObject rSelectedSeed = seeds[Random.Range(0, seeds.Count)];
		foreach(GameObject rSeed in seeds)
		{
			if(rSeed != rSelectedSeed)
			{
				rSeed.SetActive(false);
			}
		}
		
		// Explosion
		List<Rigidbody> oRigidbodyParts = new List<Rigidbody>();
		oRigidbodyParts.AddRange(chestRigidbodies);
		oRigidbodyParts.Add(rSelectedSeed.rigidbody);
		Vector3 f3ExplosionPosition = nutModel.position;
		foreach(Rigidbody rRigidBody in oRigidbodyParts)
		{
			rRigidBody.AddForce((rRigidBody.position - f3ExplosionPosition) * explosionForce + explosionUpwardModifier * Vector3.up);
			rRigidBody.angularVelocity = Random.insideUnitSphere * seedAngularRotationMax * Mathf.Deg2Rad;
		}
		
		Invoke("AutoDestroy", duration);
	}
	
	private void AutoDestroy()
	{
		Destroy(gameObject);
	}
}
