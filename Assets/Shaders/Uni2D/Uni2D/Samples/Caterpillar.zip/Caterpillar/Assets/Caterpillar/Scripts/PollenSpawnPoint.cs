﻿using UnityEngine;
using System.Collections;

public class PollenSpawnPoint : SubWave
{
	private Pollen m_oPollen;
	private bool m_bSpawned;
	
	public Pollen Spawn()
	{
		if(m_bSpawned == false)
		{
			m_oPollen = Instantiate(ItemFactory.Instance.pollenPrefab) as Pollen;
			m_oPollen.transform.parent = transform.parent;
			m_oPollen.transform.localPosition = transform.localPosition;
			m_oPollen.transform.localRotation = transform.localRotation;
			m_oPollen.transform.localScale = transform.localScale;
			
			m_oPollen.onPollenPickedUp += OnPollenPickedUp;
			
			m_bSpawned = true;
			
			SoundPlayer_Pollen_Spawn.Instance.PlayPollenSpawnSound();
		}
		
		return m_oPollen;
	}
	
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.green;
		Gizmos.DrawSphere(transform.position, 1.0f);
	}
	
	private void OnPollenPickedUp(Pollen a_rPollen)
	{
		SubWaveEnd();
	}
}
