using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Button_ActivateWhenPressed : MonoBehaviour
{	
	public Button button;
	
	public GameObject gameObjectToActivate;
	
	private void Awake()
	{
		button.onButtonDown += OnButtonDown;
		button.onButtonUp += OnButtonUp;
		
		UpdateSprite();
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonDown -= OnButtonDown;
			button.onButtonUp -= OnButtonUp;
		}
	}
	
	private void OnButtonDown()
	{
		UpdateSprite();
	}
	
	private void OnButtonUp()
	{
		UpdateSprite();
	}
	
	private void UpdateSprite()
	{
		if(button == null)
		{
			return;
		}
		
		Activate(button.Pressed);
	}
	
	private void Activate(bool a_bActivate)
	{
		if(gameObjectToActivate == null)
		{
			return;
		}
		
		gameObjectToActivate.SetActive(a_bActivate);
	}
}