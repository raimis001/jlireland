﻿using UnityEngine;
using System.Collections;

public class PlayAnimation : MonoBehaviour 
{
	public float delay;

	private Animator m_rAnimator;

	private void Awake()
	{
		m_rAnimator = GetComponent<Animator>();
		m_rAnimator.speed = 0.0f;
	
		Invoke("StartAnimation", delay);
	}
	
	private void StartAnimation()
	{
		m_rAnimator.speed = 1.0f;
	}
}
