using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Button : MonoBehaviour
{	
	public System.Action onButtonClick;
	public System.Action onButtonDown;
	public System.Action onButtonUp;
	
	public Collider2D hitZone;

	public Camera cameraComponent;
		
	private bool m_bButtonPressed;
	
	private Vector2 m_f2CursorPosition;	
	
	public bool Pressed
	{
		get
		{
			return m_bButtonPressed;
		}
	}
	
	private void Update()
	{
		UpdateButton();
	}
	
	private void UpdateButton()
	{
		if(m_bButtonPressed)
		{
			if(Input.GetMouseButton(0))
			{
				m_f2CursorPosition = Input.mousePosition;
			}
			else
			{
				m_bButtonPressed = false;
				if(IsCursorInTheTouchZone())
				{
					ReleaseButton();
				}
				else
				{	
					CancelButton();
				}
			}
		}
		else
		{
			if(Input.GetMouseButtonDown(0))
			{
				m_f2CursorPosition = Input.mousePosition;
				if(IsCursorInTheTouchZone())
				{
					m_bButtonPressed = true;
					PressButton();
				}
			}
		}
	}
	
	private bool IsCursorInTheTouchZone()
	{
		if(hitZone == null)
		{
			return true;
		}
		
		Vector2 f2CursorWorldPosition = cameraComponent.ScreenToWorldPoint(m_f2CursorPosition);
		return hitZone.OverlapPoint(f2CursorWorldPosition);
	}
	
	private void PressButton()
	{
		if(onButtonDown != null)
		{
			onButtonDown();
		}
	}
	
	private void ReleaseButton()
	{
		if(onButtonClick != null)
		{
			onButtonClick();
		}
		NotifyButtonUp();
	}
	
	private void CancelButton()
	{
		NotifyButtonUp();
	}
	
	private void NotifyButtonUp()
	{
		if(onButtonUp != null)
		{
			onButtonUp();
		}
	}
}