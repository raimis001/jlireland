using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Pollen_Collect : MonoBehaviour
{	
	public SoundPlayer_GradationSequence gradationSequence;
	
	public AudioClip pollenCollect;
	
	public float pollenCollectVolume = 0.3f;
	
	private static SoundPlayer_Pollen_Collect ms_oInstance;
	
	public static SoundPlayer_Pollen_Collect Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlayPollenStartCollectSound()
	{
		gradationSequence.PlaySound();
	}
	
	public void PlayPollenEndCollectSound()
	{
		SoundManager.Instance.PlaySound(pollenCollect, pollenCollectVolume);
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
