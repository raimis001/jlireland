﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_BodyParts : MonoBehaviour
{
	public Caterpillar caterpillar;
	
	public void FixedUpdate()
	{	
		float fMaxMovement = 0.0f;
		bool bNeedToMoveFromGround = false;
		foreach(Caterpillar_BodyPart rBodyPart in caterpillar.bodyParts)
		{
			float fMovement = rBodyPart.GetPenetrationAfterBranchUpdate();
			
			if(fMovement > fMaxMovement)
			{
				fMaxMovement = fMovement;
				bNeedToMoveFromGround = true;
			}
		}
		
		if(bNeedToMoveFromGround)
		{
			if(fMaxMovement >= caterpillar.penetrationMax)
			{
				foreach(Caterpillar_BodyPart rBodyPart in caterpillar.bodyParts)
				{
					rBodyPart.MoveFromGround(fMaxMovement);
				}
			}	
		}
		
		/*if(iMaxMovementBodyPartIndex != -1)
		{
			for(int i = iMaxMovementBodyPartIndex - 1; i >= 0; --i)
			{
				EnforceChainConstraint(i, i + 1);
			}
			
			for(int i = iMaxMovementBodyPartIndex + 1; i < caterpillar.bodyParts.Length; ++i)
			{
				EnforceChainConstraint(i, i - 1);
			}
		}*/
	}
}
