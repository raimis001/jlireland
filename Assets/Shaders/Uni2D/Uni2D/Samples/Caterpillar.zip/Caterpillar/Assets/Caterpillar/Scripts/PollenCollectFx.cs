﻿using UnityEngine;
using System.Collections;

public class PollenCollectFx : MonoBehaviour
{
	public float collectDuration = 0.5f;
	
	public Animator collectAnimator;
	
	public ParticleSystem pollenDepleteParticleSystem;
	
	private Vector3 m_f3CollectVelocity;
	
	private float collectTimeRemaining;
	
	private Transform m_rTarget;
	
	private System.Action m_rOnCollectEnd;
	
	public void StartCollect(Vector2 a_f2CollectStartVelocity, Transform a_rTarget, System.Action a_rOnCollectEnd)
	{
		m_f3CollectVelocity = a_f2CollectStartVelocity;
		collectTimeRemaining = collectDuration;
		m_rTarget = a_rTarget;
		m_rOnCollectEnd = a_rOnCollectEnd;
		
		collectAnimator.speed = 1.0f/collectDuration;
	}
	
	private void Awake()
	{
		pollenDepleteParticleSystem.gameObject.SetActive(false);
	}
	
	private void Start()
	{
		pollenDepleteParticleSystem.gameObject.SetActive(true);
	}
	
	private void LateUpdate()
	{
		UpdateCollect();
	}
	
	private void StopCollect()
	{
		if(m_rOnCollectEnd != null)
		{
			m_rOnCollectEnd();
		}
		pollenDepleteParticleSystem.transform.parent = null;
		Destroy(gameObject);
	}
	
	private void UpdateCollect()
	{
		Vector3 f3Target = m_rTarget.position;
		collectTimeRemaining -= Time.deltaTime;
		if(collectTimeRemaining > 0.0f)
		{
			transform.position = Vector3.SmoothDamp(transform.position, f3Target, ref m_f3CollectVelocity, collectTimeRemaining);
		}
		else
		{
			StopCollect();
		}
	}
}
