using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundPlayer_Button : MonoBehaviour
{	
	[System.Serializable]
	public class Sound
	{
		public AudioClip sound;
		public float volume = 1.0f;
		
		public void Play()
		{
			SoundManager.Instance.PlaySound(sound, volume);
		}
	}
	
	public Sound down;
	
	public Sound up;
	
	private static SoundPlayer_Button ms_oInstance;
	
	public static SoundPlayer_Button Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	public void PlayDown()
	{
		down.Play();
	}
	
	public void PlayUp()
	{
		up.Play();
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}