﻿using UnityEngine;
using System.Collections;

public class Parameters_PollenChain : MonoBehaviour
{
	public float spaceBetweenPollenAtSpawn = 0.25f;
	public float spaceBetweenPollen = 1.25f;
	public float minimumSpaceBetweenPosition = 0.25f;
	public int maxSavedPositionCount = 50;
	
	private static Parameters_PollenChain ms_oInstance;
	
	public static Parameters_PollenChain Instance
	{
		get
		{
			return ms_oInstance;
		}
	}
	
	private void Awake()
	{
		if(ms_oInstance == null)
		{
			ms_oInstance = this;
		}
		else
		{
			Debug.LogWarning("This is a singleton. You can't have more than one instance.");
			Destroy(gameObject);
		}
	}
	
	private void OnDestroy()
	{
		ms_oInstance = null;
	}
}
