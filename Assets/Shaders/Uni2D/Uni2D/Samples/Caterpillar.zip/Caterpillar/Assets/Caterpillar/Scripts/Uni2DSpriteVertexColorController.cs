using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode()]
public class Uni2DSpriteVertexColorController : MonoBehaviour 
{	
	public Color color = Color.white;
	
	private Uni2DSprite m_rSprite;
	
	private void Update()
	{
		if(m_rSprite == null)
		{
			m_rSprite = GetComponent<Uni2DSprite>();
		}
		
		if(m_rSprite != null)
		{
			m_rSprite.VertexColor = color;
		}	
	}
}
