﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode()]
public class PollenPreSpawnFx : MonoBehaviour
{		
	public string sortingLayerName = "Pollen";
	public int orderInLayer = 1;
	
	public ParticleSystem particleSystemComponent;
	
	private bool m_bFxInProgress = false; 
	
	private bool m_bAnchored = false;
	private Vector2 m_f2SpawnPosition;
	
	public static PollenPreSpawnFx CreatePollenPreSpawnFX(GameObject a_rGameObject)
	{
		PollenPreSpawnFx oPreSpawnFx = Instantiate(ItemFactory.Instance.pollenPreSpawnFxPrefab) as PollenPreSpawnFx;
		oPreSpawnFx.transform.parent = a_rGameObject.transform;
		oPreSpawnFx.transform.localPosition = Vector2.zero;
		oPreSpawnFx.transform.localRotation = Quaternion.identity;
		
		return oPreSpawnFx;
	}
	
	public void StartFx(float a_fDelay = 0.0f)
	{
		if(m_bFxInProgress)
		{
			return;
		}
		
		Invoke("_StartFx", a_fDelay);
	}
	
	public void StopFx()
	{
		if(m_bFxInProgress == false)
		{
			return;
		}
		
		SoundPlayer_Pollen_PreSpawnFx.Instance.UnregisterSoundPlayer();
		
		particleSystemComponent.enableEmission = false;
		m_bFxInProgress = false;
	}
	
	public void AnchorFx(Vector2 a_f2SpawnPosition)
	{
		if(m_bFxInProgress == false)
		{
			return;
		}
		
		m_f2SpawnPosition = a_f2SpawnPosition;
		m_bAnchored = true;
	}
	
	private void Awake()
	{
		SetSorting();
	}
	
	private void Update()
	{
		if(Application.isPlaying == false)
		{
			SetSorting();
		}
	}
	
	private void LateUpdate()
	{
		if(m_bFxInProgress == false)
		{
			return;
		}
		
		if(m_bAnchored)
		{
			transform.position = m_f2SpawnPosition;
		}
	}
	
	private void _StartFx()
	{
		if(m_bFxInProgress)
		{
			return;
		}
		
		SoundPlayer_Pollen_PreSpawnFx.Instance.RegisterSoundPlayer();
		
		particleSystemComponent.Play();
		particleSystemComponent.enableEmission = true;
		m_bFxInProgress = true;
	}
	
	private void SetSorting()
	{
		if(particleSystemComponent != null)
		{
			particleSystemComponent.renderer.sortingLayerName = sortingLayerName;
			particleSystemComponent.renderer.sortingOrder = orderInLayer;
		}
	}
}
