﻿using UnityEngine;
using System.Collections;

public class PollenLose : MonoBehaviour
{	
	public Vector2 losePosition;
	
	public Vector2 loseStartVelocity;
	
	public PollenCounter pollenCounter;
	
	public int numberOfPollenToLose;
	
	public float pollenLoseRate;
	
	public float loseDuration;
	
	private int m_iLoseCount = 0;
	
	private void Start()
	{
		NextLose();
		if(numberOfPollenToLose > 1)
		{
			InvokeRepeating("NextLose", pollenLoseRate, pollenLoseRate);
		}
	}
	
	private void NextLose()
	{
		StartLose();
		++m_iLoseCount;
		
		if(m_iLoseCount >= numberOfPollenToLose)
		{
			Destroy(this);
		}
	}
	
	private void StartLose()
	{
		pollenCounter.Add(-1);
		
		PollenLoseFx oPollenLoseFx = Instantiate(ItemFactory.Instance.pollenLoseFxPrefab) as PollenLoseFx;
		oPollenLoseFx.transform.position = losePosition;
		oPollenLoseFx.loseDuration = loseDuration;
		oPollenLoseFx.StartLose(loseStartVelocity);
	}
}