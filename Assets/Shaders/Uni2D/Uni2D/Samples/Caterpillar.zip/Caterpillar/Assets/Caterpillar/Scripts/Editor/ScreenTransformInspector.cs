using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(ScreenTransform))]
[CanEditMultipleObjects]
public class ScreenTransformInspector : Editor
{
	public override void OnInspectorGUI()
	{
		DrawDefaultInspector();
		
		if(GUILayout.Button("Save Current Viewport Position"))
		{
			foreach(Object rTarget in targets)
			{
				ScreenTransform rScreenTransform = rTarget as ScreenTransform;
				if(rScreenTransform != null)
				{
					rScreenTransform.SaveCurrentViewportPosition();
				}
			}
		}
		
		if(GUILayout.Button("Apply Saved Viewport Position"))
		{
			foreach(Object rTarget in targets)
			{
				ScreenTransform rScreenTransform = rTarget as ScreenTransform;
				if(rScreenTransform != null)
				{
					rScreenTransform.ApplySavedViewportPosition();
				}
			}
		}
	}
}