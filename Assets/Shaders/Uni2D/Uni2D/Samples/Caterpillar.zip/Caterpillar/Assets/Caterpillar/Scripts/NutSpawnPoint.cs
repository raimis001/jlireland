﻿using UnityEngine;
using System.Collections;

public class NutSpawnPoint : SubWave
{
	public float delay = 0.0f;
	
	private void Start()
	{
		Invoke("Spawn", delay);
	}
	
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.blue;
		Gizmos.DrawSphere(transform.position, 1.0f);
	}
	
	private void Spawn()
	{
		Nut oNut = Instantiate(ItemFactory.Instance.nutPrefab) as Nut;
		oNut.transform.parent = transform.parent;
		oNut.transform.localPosition = transform.localPosition;
		oNut.transform.localRotation = transform.localRotation;
		oNut.transform.localScale = transform.localScale;
		
		oNut.transform.parent = null;
		
		oNut.onNutEnd += OnNutEnd;
	}
	
	private void OnNutEnd(Nut a_rNut)
	{
		SubWaveEnd();
	}
}
