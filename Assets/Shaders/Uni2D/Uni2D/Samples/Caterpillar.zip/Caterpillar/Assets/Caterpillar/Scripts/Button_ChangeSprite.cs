using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Button_ChangeSprite : MonoBehaviour
{	
	public Button button;
	
	public SpriteRenderer spriteRenderer;
	
	public Sprite spriteDown;
	
	private Sprite m_rLastSpriteUp;
	
	private void Awake()
	{	
		if(spriteRenderer != null)
		{
			m_rLastSpriteUp = spriteRenderer.sprite;
		}
		
		button.onButtonDown += OnButtonDown;
		button.onButtonUp += OnButtonUp;
		
		UpdateSprite();
	}
	
	private void OnDestroy()
	{
		if(button != null)
		{
			button.onButtonDown -= OnButtonDown;
			button.onButtonUp -= OnButtonUp;
		}
	}
	
	private void OnButtonDown()
	{
		UpdateSprite();
	}
	
	private void OnButtonUp()
	{
		UpdateSprite();
	}
	
	private void UpdateSprite()
	{
		if(button == null)
		{
			return;
		}
		
		SetSpriteDown(button.Pressed);
	}
	
	private void SetSpriteDown(bool a_bDown)
	{
		if(spriteRenderer == null)
		{
			return;
		}
		
		if(a_bDown)
		{
			m_rLastSpriteUp = spriteRenderer.sprite;
			spriteRenderer.sprite = spriteDown;
		}
		else
		{
			spriteRenderer.sprite = m_rLastSpriteUp;
		}
	}
}