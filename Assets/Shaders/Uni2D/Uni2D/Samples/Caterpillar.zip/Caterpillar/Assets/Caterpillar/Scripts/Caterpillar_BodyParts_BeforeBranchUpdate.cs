﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_BodyParts_BeforeBranchUpdate : MonoBehaviour
{
	public Caterpillar caterpillar;
	
	public void FixedUpdate()
	{	
		foreach(Caterpillar_BodyPart rBodyPart in caterpillar.bodyParts)
		{
			rBodyPart.BeforeBranchUpdate();
		}
	}
}
