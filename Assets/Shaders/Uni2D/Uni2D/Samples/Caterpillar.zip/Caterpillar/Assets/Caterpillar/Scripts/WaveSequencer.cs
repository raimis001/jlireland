﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WaveSequencer : MonoBehaviour
{
	public Wave[] waves; 
	
	public float startTime = 0.0f;
	
	public float delayBetweenWave = 1.0f;
	
	public bool loop = true;
	public bool shuffled = true;
	
	private Wave m_oCurrentWave;
	
	private int m_iCurrentWaveIndex = -1;
	
	private bool m_bSequenceEnd;
	
	private List<int> m_oShuffledIndices = new List<int>();
	
	public void WaveEnd(Wave a_rWave)
	{
		if(m_bSequenceEnd)
		{
			return;
		}
		
		if(m_oCurrentWave == a_rWave)
		{
			Invoke("NextWave", delayBetweenWave);
		}
	}
	
	private void Awake()
	{
		CreateShuffleIndices();
		GameSequence.Instance.onStateChange += OnStateChange;
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
	}
	
	private void OnStateChange()
	{
		switch(GameSequence.Instance.State)
		{
			case GameSequence.EState.PlayGame:
			{
				StartSequence();
			}
			break;
			
			case GameSequence.EState.GameOver:
			{
				EndSequence();
			}
			break;
		}
	}
	
	private void StartSequence()
	{
		Invoke("NextWave", startTime);
	}
	
	private void EndSequence()
	{
		CancelInvoke("NextWave");
		m_bSequenceEnd = true;
		//Debug.Log("EndSequence");
	}
	
	private void CreateShuffleIndices()
	{
		List<int> oIndices = new List<int>();
		for(int i = 0; i < waves.Length; ++i)
		{
			oIndices.Add(i);
		}
		
		while(oIndices.Count > 0)
		{
			int iNextPickedIndex = Random.Range(0, oIndices.Count - 1);
			
			m_oShuffledIndices.Add(oIndices[iNextPickedIndex]);
			oIndices.RemoveAt(iNextPickedIndex);
		}
	}
	
	private void NextWave()
	{
		if(m_bSequenceEnd)
		{
			return;
		}
		
		DestroyLastWave();
		
		++m_iCurrentWaveIndex;
		if(m_iCurrentWaveIndex >= waves.Length)
		{
			if(loop)
			{
				m_iCurrentWaveIndex = 0;
			}
			else
			{
				EndSequence();
				return;
			}
		}
		
		NewWave();
	}
	
	private void DestroyLastWave()
	{
		if(m_oCurrentWave != null)
		{
			Destroy(m_oCurrentWave.gameObject);
		}
	}
	
	private void NewWave()
	{
		int iPlayIndex = GetPlayIndex(m_iCurrentWaveIndex);
		
		m_oCurrentWave = Instantiate(waves[iPlayIndex]) as Wave;
		m_oCurrentWave.transform.parent = transform;
		m_oCurrentWave.waveSequencer = this;
	}
	
	private int GetPlayIndex(int a_iIndex)
	{	
		if(shuffled)
		{
			return m_oShuffledIndices[a_iIndex];
		}
		else
		{
			return a_iIndex;
		}
	}
}
