using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameMusic : MonoBehaviour
{
	public AudioClip musicClip;
	
	public float volume = 0.3f;
	
	public float smoothTime = 0.5f; 
	
	private float m_fVolumePercent;
	
	private float m_fVolumePercentTarget;
	
	private float m_fSmoothVelocity;
	
	private AudioSource m_rAudioSource;
	
	private void Awake()
	{	
		m_rAudioSource = gameObject.AddComponent<AudioSource>();
		m_rAudioSource.clip = musicClip;
		m_rAudioSource.loop = true;
		
		SetVolumePercent(0.0f);
		GotoVolumePercent(1.0f);
		
		m_rAudioSource.Play();
		
		GameSequence.Instance.onStateChange += OnStateChange;
	}
	
	private void OnDestroy()
	{
		if(GameSequence.Instance != null)
		{
			GameSequence.Instance.onStateChange -= OnStateChange;
		}
	}
	
	private void Update()
	{
		float fVolumePercent = GetVolumePercent();
		
		fVolumePercent = Mathf.SmoothDamp(fVolumePercent, m_fVolumePercentTarget, ref m_fSmoothVelocity, smoothTime);
		
		SetVolumePercent(fVolumePercent);
	}
	
	private void OnStateChange()
	{
		if(GameSequence.Instance.State == GameSequence.EState.GameOver)
		{
			GotoVolumePercent(0.0f);
		}
	}
	
	private void GotoVolumePercent(float a_fVolumePercentTarget)
	{
		m_fVolumePercentTarget = a_fVolumePercentTarget;
	}
	
	private float GetVolumePercent()
	{
		return m_fVolumePercent;
	}
	
	private void SetVolumePercent(float a_fVolumePercent)
	{
		m_fVolumePercent = a_fVolumePercent;
		m_rAudioSource.volume = m_fVolumePercent * volume * SoundManager.Instance.MasterVolume;
	}
}
