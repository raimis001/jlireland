﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Branch_RemoveBottom : MonoBehaviour 
{	
	public float bottom = -1000.0f;
	
	private MeshCollider m_rMeshCollider;
	private PolygonCollider2D m_rPolygonCollider2D;
	
	private void Awake()
	{
		m_rMeshCollider = GetComponent<MeshCollider>();
		m_rPolygonCollider2D = GetComponent<PolygonCollider2D>();
	}
	
	private void FixedUpdate()
	{
		if(m_rPolygonCollider2D != null)
		{
			Vector2[] oVertices = m_rPolygonCollider2D.points;
			
			for(int i = 0; i < oVertices.Length; ++i)
			{
				Vector2 f2Normal = GetNormal(oVertices, i);
				if(f2Normal.y <= 0.0f)
				{
					Vector2 f2Vertex = oVertices[i];
					f2Vertex.y = bottom;
					oVertices[i] = f2Vertex;
				}
			}
			
			m_rPolygonCollider2D.points = oVertices;
		}
		else
		{
			Mesh rMesh = m_rMeshCollider.sharedMesh;
			
			Vector3[] oVertices = rMesh.vertices;
			Vector3[] oNormals = rMesh.normals;
			
			for(int i = 0; i < oVertices.Length; ++i)
			{
				Vector3 f3Normal = oNormals[i];
				if(f3Normal.y <= 0.0f)
				{
					Vector3 f3Vertex = oVertices[i];
					f3Vertex.y = bottom;
					oVertices[i] = f3Vertex;
				}
			}
			
			rMesh.vertices = oVertices;
			
			m_rMeshCollider.sharedMesh = null;
			m_rMeshCollider.sharedMesh = rMesh;
		}
	}
	
	private Vector2 GetNormal(Vector2[] a_rVertices, int a_iIndex)
	{
		int iVertexCount = a_rVertices.Length;
		Vector2 f2A = a_rVertices[(a_iIndex - 1 + iVertexCount)%iVertexCount];
		Vector2 f2B = a_rVertices[a_iIndex];
		Vector2 f2C = a_rVertices[(a_iIndex + 1)%iVertexCount];
		
		Vector2 f2AB = f2B - f2A;
		Vector2 f2BC = f2C - f2B;
		
		Vector2 f2ABNormal = new Vector2(-f2AB.y, f2AB.x).normalized;
		Vector2 f2BCNormal = (new Vector2(-f2BC.y, f2BC.x)).normalized;
		
		Vector2 f2BNormal = (f2ABNormal + f2BCNormal).normalized;
		
		return f2BNormal;
	}
}
