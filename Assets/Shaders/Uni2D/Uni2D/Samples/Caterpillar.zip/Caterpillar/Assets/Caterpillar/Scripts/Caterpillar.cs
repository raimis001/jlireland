﻿using UnityEngine;
using System.Collections;

public class Caterpillar : MonoBehaviour 
{	
	public float moveAcceleration = 1000.0f;
	public float maxMoveSpeed = 8.0f;
	
	public float jump = 6.0f;
	public float jumpFromNutTop = 60.0f;
	public float bounceFromNutTop = 1.5f;
	public int jumpBodyPartBegin = 0;
	public int jumpBodyPartEnd = 9;
	
	public Caterpillar_BodyPart[] bodyParts;
	
	public float penetrationMax = 0.025f;
	public float penetrationVelocityMax = 0.025f;
	
	public float deviceAccelerationMoveDeadZone = 0.01f;
	public float deviceAccelerationMoveMax = 0.3f;
	
	public float deviceAccelerationJump = 0.1f;
	public float deviceAccelerationJumpSampleRate = 0.1f;
	
	private bool m_bJumpButtonWasPressed;
	
	private bool m_bJumpOnTopOfNut;
	
	private float m_fLastMovementDirection;
	
	private float m_fLastSampledJumpAcceleration;
	private float m_fTimeRemainingBeforeLastJumpAccelerationSample;
	
	private bool m_bIsGrounded;
	
	public bool IsGrounded
	{
		get
		{
			return m_bIsGrounded;
		}
	}
	
	private float Horizontal
	{
		get
		{
			Vector3 f3Acceleration = Input.acceleration;
			float fAccelerationAbs = Mathf.Abs(f3Acceleration.x);
			if(fAccelerationAbs > deviceAccelerationMoveDeadZone)
			{
				return Mathf.Clamp01((fAccelerationAbs - deviceAccelerationMoveDeadZone)/deviceAccelerationMoveMax) * Mathf.Sign(f3Acceleration.x);
			}
			else
			{
				return Input.GetAxis("Horizontal");
			}
		}
	}
	
	private bool Jump
	{
		get
		{
			Vector3 f3Acceleration = Input.acceleration;
			float fAcceleration = f3Acceleration.z;
			float fAccelerationDiff = fAcceleration - m_fLastSampledJumpAcceleration;
			if(fAccelerationDiff > deviceAccelerationJump)
			{
				return true;
			}
			else
			{
				return Input.GetButton("Jump");
			}
		}
	}
	
	public void JumpOnTopOfNut()
	{
		m_bJumpOnTopOfNut = true;
	}
	
	private void Awake()
	{
		UpdateJumpAccelerationDetection();
	}
	
	private void FixedUpdate()
	{
		UpdateIsGrounded();
		
		if(GameSequence.Instance.State != GameSequence.EState.PlayGame)
		{
			return;
		}
		
		EnsureParametersValidity();
		
		float fHorizontalAxis = Horizontal;
		//Debug.Log(fHorizontalAxis);
		if(fHorizontalAxis != 0.0f)
		{
			Move(moveAcceleration * fHorizontalAxis);	
			m_fLastMovementDirection = fHorizontalAxis;
		}

		bool bJumpButtonIsPressed = Jump;
		if(m_bJumpOnTopOfNut)
		{
			JumpFromNutTop(m_fLastMovementDirection < 0.0f);
			m_bJumpOnTopOfNut = false;
		}
		else
		{
			if((bJumpButtonIsPressed && m_bJumpButtonWasPressed == false))
			{
				JumpFromGround(m_fLastMovementDirection > 0.0f);
			}
		}
		m_bJumpButtonWasPressed = bJumpButtonIsPressed;
		
		UpdateJumpAccelerationDetection();
	}
	
	private void UpdateJumpAccelerationDetection()
	{
		if(m_fTimeRemainingBeforeLastJumpAccelerationSample <= 0.0f)
		{
			m_fTimeRemainingBeforeLastJumpAccelerationSample = deviceAccelerationJumpSampleRate;
			Vector3 f3Acceleration = Input.acceleration;
			float fAcceleration = f3Acceleration.z;
			m_fLastSampledJumpAcceleration = fAcceleration;
		}
		else
		{
			m_fTimeRemainingBeforeLastJumpAccelerationSample -= Time.fixedDeltaTime;
		}
	}
	
	private void EnsureParametersValidity()
	{
		jumpBodyPartBegin = Mathf.Clamp(jumpBodyPartBegin, 0, bodyParts.Length - 1);
		jumpBodyPartEnd = Mathf.Clamp(jumpBodyPartEnd, 0, bodyParts.Length - 1);
		
		if(jumpBodyPartBegin > jumpBodyPartEnd)
		{
			int iJumpBodyPartMax = jumpBodyPartBegin;
			jumpBodyPartBegin = jumpBodyPartEnd;
			jumpBodyPartEnd = iJumpBodyPartMax;
		}
	}
	
	private void Move(float a_fForce)
	{
		if(a_fForce == 0.0f)
		{
			return;
		}
		//foreach(Caterpillar_BodyPart rBodyPart in bodyParts)
		Caterpillar_BodyPart rBodyPart;
		if(a_fForce < 0.0f)
		{
			rBodyPart = bodyParts[1];
		}
		else
		{
			rBodyPart = bodyParts[bodyParts.Length - 1];
		}
		
		
		float fVelocityAddition = a_fForce * Time.fixedDeltaTime;
		float fNextVelocityAbs = Mathf.Abs(rBodyPart.Velocity.x + fVelocityAddition);
		if(fNextVelocityAbs > maxMoveSpeed)
		{
			float fVelocityInExcess = fNextVelocityAbs - maxMoveSpeed;
			float fForceInExcess = fVelocityInExcess/Time.fixedDeltaTime;
			//Debug.Log("Force : " + a_fForce);
			a_fForce -= Mathf.Sign(a_fForce) * fForceInExcess;
			//Debug.Log("In Excess : " + fForceInExcess);
			//Debug.Log("Cut Force : " + a_fForce);
		}
		
		rBodyPart.AddForce(Vector2.right * a_fForce);
	}
	
	private void UpdateIsGrounded()
	{
		m_bIsGrounded = false;
		foreach(Caterpillar_BodyPart rBodyPart in bodyParts)
		{
			if(rBodyPart.IsGrounded)
			{
				m_bIsGrounded = true;
				break;
			}
		}
	}
	
	private void JumpFromGround(bool a_bReverse)
	{
		if(IsGrounded)
		{
			ExecuteJump(a_bReverse, jump, 0.0f);
		}
	}
	
	private void JumpFromNutTop(bool a_bReverse)
	{
		ExecuteJump(a_bReverse, jumpFromNutTop, bounceFromNutTop);	
	}
	
	private void ExecuteJump(bool a_bReverse, float a_fJump, float a_fBounce)
	{	
		// Reverse again if on the back
		bool bOnTheBack = false;
		foreach(Caterpillar_BodyPart rBodyPart in bodyParts)
		{
			if(rBodyPart.transform.up.y < 0.0f)
			{
				bOnTheBack = true;
				break;
			}
		}
		if(bOnTheBack)
		{
			a_bReverse = !a_bReverse;
		}
		
		for(int i = jumpBodyPartBegin; i <= jumpBodyPartEnd; ++i)
		{
			int iBodyPartIndex = i;
			if(a_bReverse)
			{
				iBodyPartIndex = bodyParts.Length - 1 - iBodyPartIndex;
			}
			
			Caterpillar_BodyPart rBodyPart = bodyParts[iBodyPartIndex];
			
			Vector2 f2Velocity = rBodyPart.Velocity;
			if(f2Velocity.y <= 0.0f)
			{
				f2Velocity.y *= -a_fBounce;
			}
			else
			{
				f2Velocity.y = 0.0f;
			}
			f2Velocity.y += a_fJump;
			rBodyPart.Velocity = f2Velocity;
		}
		SoundPlayer_Caterpillar.Instance.PlayJump();
	}
}
