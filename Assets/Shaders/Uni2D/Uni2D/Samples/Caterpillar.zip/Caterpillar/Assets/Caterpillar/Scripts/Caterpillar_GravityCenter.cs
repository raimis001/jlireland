﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Caterpillar_GravityCenter : MonoBehaviour
{
	public Caterpillar caterpillar;
	
	private Vector2 m_f2LastPosition;
	
	private Vector2 m_f2Velocity = Vector2.zero;
	
	bool m_bFirstUpdate = true;
	
	public Vector2 Velocity
	{
		get
		{
			return m_f2Velocity;
		}
	}
	
	private void FixedUpdate()
	{
		// Compute Position
		Vector2 f2GravityCenterPosition = Vector2.zero;
		int iBodyPartCount = 0;
		foreach(Caterpillar_BodyPart rBodyPart in caterpillar.bodyParts)
		{
			if(rBodyPart != null)
			{
				++iBodyPartCount;
				f2GravityCenterPosition += (Vector2)rBodyPart.transform.position;
			}
		}
		
		if(iBodyPartCount > 0)
		{
			f2GravityCenterPosition /= (float)iBodyPartCount;
		}
		
		transform.position = f2GravityCenterPosition;
		
		// Keep track of the velocity
		if(m_bFirstUpdate)
		{
			m_bFirstUpdate = false;
		}
		else
		{
			m_f2Velocity = f2GravityCenterPosition - m_f2LastPosition;
		}
		
		m_f2LastPosition = f2GravityCenterPosition;
	}
}
