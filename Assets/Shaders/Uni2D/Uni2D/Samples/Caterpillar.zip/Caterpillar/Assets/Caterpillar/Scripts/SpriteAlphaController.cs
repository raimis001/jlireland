﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[ExecuteInEditMode()]
public class SpriteAlphaController : MonoBehaviour 
{	
	public SpriteRenderer spriteRenderer;
	
	public float alpha = 1.0f;
	
	private void LateUpdate()
	{
		if(spriteRenderer == null)
		{
			return;
		}
		
		Color oColor = spriteRenderer.color;
		if(oColor.a != alpha)
		{
			oColor.a = alpha;
			spriteRenderer.color = oColor;
		}
	}
}
